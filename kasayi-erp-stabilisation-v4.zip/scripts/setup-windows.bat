@echo off
REM ============================================================
REM  KasayiMultiBusiness ERP - Installation Windows 10
REM  Double-cliquez sur ce fichier OU lancez-le depuis CMD.
REM ============================================================
setlocal
cd /d "%~dp0.."

echo.
echo ============================================================
echo   KasayiMultiBusiness ERP - Installation Windows
echo ============================================================
echo.

if not exist ".env" (
  echo [1/6] Creation du fichier .env depuis .env.example...
  copy /Y ".env.example" ".env" >nul
  echo.
  echo   *** IMPORTANT ***
  echo   Ouvrez le fichier .env et renseignez DATABASE_URL
  echo   avec le mot de passe de votre utilisateur PostgreSQL.
  echo   Exemple :
  echo   DATABASE_URL=postgresql://postgres:MonMotDePasse@localhost:5432/kasayi_erp
  echo.
  echo   Puis relancez ce script.
  pause
  exit /b 1
)

echo [1/6] Installation des dependances npm...
call npm install || goto :erreur

echo [2/6] Creation de la base PostgreSQL si absente...
call npm run db:create || goto :erreur

echo [3/6] Creation des tables (migrations)...
call npm run db:migrate || goto :erreur

echo [4/6] Chargement des donnees de demonstration...
call npm run db:seed || goto :erreur

echo [5/6] Verification du schema...
call npm run db:check || goto :erreur

echo [6/6] Termine !
echo.
echo   Demarrer le serveur :  npm run dev
echo   Site public         :  http://localhost:3000
echo   Connexion agent     :  http://localhost:3000/login
echo   admin@kasayimulti.cd / admin123
echo.
pause
exit /b 0

:erreur
echo.
echo *** ERREUR *** Consultez le message ci-dessus.
echo Aide : verifiez que le service PostgreSQL tourne (services.msc)
echo        et que DATABASE_URL est correct dans .env
pause
exit /b 1
