#!/usr/bin/env node
/**
 * ─────────────────────────────────────────────────────────────
 * Migration PostgreSQL — KasayiMultiBusiness ERP
 * ─────────────────────────────────────────────────────────────
 * Node pur (aucune dépendance hors `pg`) → fonctionne partout :
 *   • Windows 10 (PowerShell / CMD) sans bash ni curl
 *   • Linux / macOS / VPS
 *   • Docker (image standalone, sans devDependencies)
 *   • Hébergeurs managés (Render, Railway, Vercel build hook…)
 *
 * Applique dans l'ordre les fichiers SQL de ./drizzle en s'appuyant
 * sur ./drizzle/meta/_journal.json et journalise chaque migration
 * dans drizzle.__drizzle_migrations (compatible drizzle-kit).
 *
 * Sécurité :
 *   - Chaque migration s'exécute dans une TRANSACTION (rollback si erreur).
 *   - Si des tables applicatives existent déjà sans journal (base créée
 *     jadis avec `drizzle-kit push`), le script fait un BASELINE :
 *     il marque les migrations comme appliquées sans rejouer le SQL.
 *     → aucune donnée existante n'est supprimée.
 *
 * Usage : npm run db:migrate
 */
import { createHash } from "node:crypto";
import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import pg from "pg";

const ROOT = process.cwd();
const DOSSIER = path.join(ROOT, "drizzle");
const SCHEMA_MIGRATIONS = "drizzle";
const TABLE_MIGRATIONS = "__drizzle_migrations";
const TABLES_TEMOINS = ["users", "roles", "services", "employees"];

// ── Chargement .env / .env.local (sans dépendance dotenv) ─────
function chargerEnv(fichier) {
  const p = path.join(ROOT, fichier);
  if (!existsSync(p)) return;
  for (const ligne of readFileSync(p, "utf8").split(/\r?\n/)) {
    const m = ligne.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (!m) continue;
    const cle = m[1];
    let val = (m[2] ?? "").trim();
    if (/^(['"]).*\1$/.test(val)) val = val.slice(1, -1);
    if (process.env[cle] === undefined) process.env[cle] = val;
  }
}
chargerEnv(".env.local");
chargerEnv(".env");

const url = process.env.DATABASE_URL;
if (!url) {
  console.error(
    "\n❌ DATABASE_URL est manquant.\n" +
      "   → Copiez .env.example vers .env puis renseignez la connexion PostgreSQL.\n" +
      "     Windows : copy .env.example .env\n",
  );
  process.exit(1);
}

const besoinSsl =
  /sslmode=(require|verify-ca|verify-full)/i.test(url) ||
  ["true", "1", "require"].includes(String(process.env.DATABASE_SSL || "").toLowerCase());

const client = new pg.Client({
  connectionString: url,
  ssl: besoinSsl ? { rejectUnauthorized: false } : undefined,
});

function infosConnexion() {
  try {
    const u = new URL(url);
    return { host: u.hostname, port: u.port || "5432", base: decodeURIComponent(u.pathname.slice(1)), user: decodeURIComponent(u.username) };
  } catch {
    return { host: "?", port: "?", base: "?", user: "?" };
  }
}

function lireJournal() {
  const jPath = path.join(DOSSIER, "meta", "_journal.json");
  if (!existsSync(jPath)) {
    throw new Error(
      "Dossier de migrations introuvable (drizzle/meta/_journal.json).\n" +
        "   Générez-le avec : npm run db:generate",
    );
  }
  const journal = JSON.parse(readFileSync(jPath, "utf8"));
  return journal.entries.map((e) => {
    const fichier = path.join(DOSSIER, `${e.tag}.sql`);
    if (!existsSync(fichier)) throw new Error(`Fichier de migration manquant : ${e.tag}.sql`);
    const contenu = readFileSync(fichier, "utf8");
    return {
      tag: e.tag,
      when: e.when,
      hash: createHash("sha256").update(contenu).digest("hex"),
      requetes: contenu
        .split("--> statement-breakpoint")
        .map((s) => s.trim())
        .filter(Boolean),
    };
  });
}

async function tableExiste(nom, schema = "public") {
  const { rows } = await client.query(
    `SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = $1 AND table_name = $2) AS ok`,
    [schema, nom],
  );
  return rows[0].ok;
}

async function main() {
  const info = infosConnexion();
  console.log("─────────────────────────────────────────────");
  console.log("  Migration PostgreSQL — KasayiMultiBusiness");
  console.log(`  Serveur : ${info.host}:${info.port}`);
  console.log(`  Base    : ${info.base}`);
  console.log(`  Rôle    : ${info.user}`);
  console.log(`  SSL     : ${besoinSsl ? "activé" : "désactivé"}`);
  console.log("─────────────────────────────────────────────");

  await client.connect();

  const migrations = lireJournal();
  const journalPresent = await tableExiste(TABLE_MIGRATIONS, SCHEMA_MIGRATIONS);

  await client.query(`CREATE SCHEMA IF NOT EXISTS "${SCHEMA_MIGRATIONS}"`);
  await client.query(
    `CREATE TABLE IF NOT EXISTS "${SCHEMA_MIGRATIONS}"."${TABLE_MIGRATIONS}" (
       id SERIAL PRIMARY KEY,
       hash text NOT NULL,
       created_at bigint
     )`,
  );

  // ── Baseline : tables déjà créées par `drizzle-kit push` ─────
  if (!journalPresent) {
    const presentes = [];
    for (const t of TABLES_TEMOINS) if (await tableExiste(t)) presentes.push(t);
    if (presentes.length > 0) {
      console.log(`ℹ  Tables déjà présentes (${presentes.join(", ")}) sans journal de migration.`);
      console.log("   → BASELINE : marquage des migrations comme appliquées (aucune donnée modifiée).");
      // Une base historique peut avoir été créée avec `drizzle-kit push`.
      // On baseline uniquement la migration initiale : les migrations ajoutées
      // ensuite doivent quand même s'exécuter (ex. ajout de colonnes).
      const base = migrations[0];
      if (base) {
        await client.query(
          `INSERT INTO "${SCHEMA_MIGRATIONS}"."${TABLE_MIGRATIONS}" (hash, created_at) VALUES ($1, $2)`,
          [base.hash, base.when],
        );
      }
      console.log(`✅ Base historique alignée sur la migration initiale.`);
      // Ne pas retourner : les migrations ultérieures sont appliquées ci-dessous.
      // Recharger le journal de migrations appliquées pour la boucle normale.

    }
  }

  const { rows: appliquees } = await client.query(
    `SELECT hash FROM "${SCHEMA_MIGRATIONS}"."${TABLE_MIGRATIONS}"`,
  );
  const dejaFaites = new Set(appliquees.map((r) => r.hash));

  let appliquees_ = 0;
  for (const m of migrations) {
    if (dejaFaites.has(m.hash)) {
      console.log(`  ⏭  ${m.tag} — déjà appliquée`);
      continue;
    }
    process.stdout.write(`  ▶  ${m.tag} … `);
    try {
      await client.query("BEGIN");
      for (const requete of m.requetes) await client.query(requete);
      await client.query(
        `INSERT INTO "${SCHEMA_MIGRATIONS}"."${TABLE_MIGRATIONS}" (hash, created_at) VALUES ($1, $2)`,
        [m.hash, m.when],
      );
      await client.query("COMMIT");
      appliquees_++;
      console.log("OK");
    } catch (e) {
      await client.query("ROLLBACK");
      console.log("ÉCHEC");
      throw e;
    }
  }

  console.log(appliquees_ === 0 ? "✅ Base déjà à jour." : `✅ ${appliquees_} migration(s) appliquée(s).`);
  await resume();
}

async function resume() {
  const { rows } = await client.query(
    `SELECT count(*)::int AS n FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'`,
  );
  console.log(`📋 ${rows[0].n} table(s) dans le schéma public.`);
  console.log("   Étape suivante : npm run db:seed");
}

main()
  .then(() => client.end())
  .catch(async (err) => {
    console.error("\n❌ Migration échouée :", err.message);
    console.error(
      "\nVérifications :\n" +
        " • Le service PostgreSQL est-il démarré ? (Windows : services.msc)\n" +
        " • La base existe-t-elle ? → npm run db:create\n" +
        " • DATABASE_URL (utilisateur / mot de passe / port / nom de base) est-il correct ?\n" +
        " • Diagnostic complet : npm run db:check\n",
    );
    await client.end().catch(() => {});
    process.exit(1);
  });
