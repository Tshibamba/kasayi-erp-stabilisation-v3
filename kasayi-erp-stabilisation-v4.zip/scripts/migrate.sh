#!/bin/bash
# Compatibilité : le vrai script est multiplateforme (Node pur).
echo "→ npm run db:migrate"
npm run db:migrate
