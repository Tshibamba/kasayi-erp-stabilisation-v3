#!/bin/bash
# Setup complet : dépendances → base → tables → données de démonstration
set -e
if [ ! -f .env ]; then
  cp .env.example .env
  echo "⚠️  .env créé depuis .env.example — renseignez DATABASE_URL puis relancez."
  exit 1
fi
npm install
npm run db:create
npm run db:migrate
npm run db:seed
npm run db:check
echo "✅ Terminé. Démarrez avec : npm run dev"
