# ============================================================
#  KasayiMultiBusiness ERP — Installation Windows (PowerShell)
#  Lancer :  powershell -ExecutionPolicy Bypass -File scripts\setup-windows.ps1
# ============================================================
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "=== KasayiMultiBusiness ERP — Installation ===" -ForegroundColor Cyan

if (-not (Test-Path ".env")) {
  Copy-Item ".env.example" ".env"
  Write-Host "`n.env créé. Renseignez DATABASE_URL (mot de passe PostgreSQL) puis relancez." -ForegroundColor Yellow
  exit 1
}

Write-Host "`n[1/5] npm install" -ForegroundColor Green
npm install

Write-Host "`n[2/5] Création de la base si absente" -ForegroundColor Green
npm run db:create

Write-Host "`n[3/5] Migrations (création des 74 tables)" -ForegroundColor Green
npm run db:migrate

Write-Host "`n[4/5] Données de démonstration" -ForegroundColor Green
npm run db:seed

Write-Host "`n[5/5] Diagnostic" -ForegroundColor Green
npm run db:check

Write-Host "`n✅ Prêt. Démarrez avec : npm run dev" -ForegroundColor Cyan
Write-Host "   http://localhost:3000  ·  agent : admin@kasayimulti.cd / admin123"
