#!/bin/bash
# ─────────────────────────────────────────────────────────────
# Compatibilité ascendante.
# L'ancien script appelait des routes HTTP (serveur démarré + curl).
# Le seed écrit désormais DIRECTEMENT en base : plus rapide, idempotent,
# et fonctionnel sous Windows sans bash/curl.
# ─────────────────────────────────────────────────────────────
echo "→ npm run db:seed"
npm run db:seed
