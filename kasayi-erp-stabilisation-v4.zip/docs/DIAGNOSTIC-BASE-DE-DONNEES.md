# Diagnostic : « la base PostgreSQL ne correspond pas au schéma / pgAdmin ne voit pas les tables »

Ce document explique **pourquoi** le problème se produisait, **ce qui a été corrigé**,
et **comment vérifier** que la chaîne complète fonctionne.

---

## 1. La chaîne complète

```
src/db/schema.ts          ← SOURCE DE VÉRITÉ (74 tables Drizzle)
        │  npm run db:generate
        ▼
drizzle/0000_init.sql + drizzle/meta/_journal.json   ← migrations versionnées
        │  npm run db:migrate      (scripts/migrate.mjs — Node pur)
        ▼
PostgreSQL  (base indiquée par DATABASE_URL)
        │
        ├──► pgAdmin 4   : Servers → <hôte:port> → Databases → <base> → Schemas → public → Tables
        │
        ▼
Backend Next.js (src/db/index.ts → Drizzle → routes /api/**)
        ▼
Frontend (site public + ERP)
```

`npm run db:check` inspecte cette chaîne de bout en bout.

---

## 2. Causes réelles identifiées dans le dépôt

| # | Problème constaté | Conséquence | Correctif |
|---|---|---|---|
| 1 | Migration lancée via `scripts/migrate.sh` → `npx drizzle-kit push` | `push` est **interactif** et ne journalise rien : s'il est interrompu (prompt de renommage/perte de données), la base reste **partiellement créée** → « certaines tables sont absentes » | `npm run db:migrate` applique les fichiers SQL **dans une transaction** et journalise dans `drizzle.__drizzle_migrations` |
| 2 | Scripts en **bash** (`bash scripts/migrate.sh`, `bash scripts/seed.sh`) | Sous **Windows 10** (PowerShell/CMD) : `bash` introuvable → migration et seed jamais exécutés → base vide | Tout passe par `npm run …` (Node pur). `scripts/setup-windows.bat` et `.ps1` fournis |
| 3 | Seed via **HTTP + curl** sur un serveur déjà démarré | `curl -X POST` échoue sous PowerShell (alias `Invoke-WebRequest`) ; nécessite `npm run dev` en parallèle ; non rejouable sereinement | `npm run db:seed` écrit **directement en base**, sans serveur, **idempotent** (aucun doublon) |
| 4 | Aucun script npm pour la base (`db:migrate`, `db:seed`…) | Chaque environnement improvisait sa procédure | Scripts npm normalisés et documentés |
| 5 | Deux fichiers de configuration Drizzle (`drizzle.config.ts` **et** `drizzle.config.json` avec des identifiants codés en dur vers une autre base) | Selon l'outil lancé, **deux bases différentes** étaient ciblées → tables créées « ailleurs » que dans la base ouverte dans pgAdmin | `drizzle.config.json` supprimé ; une seule configuration, lisant `DATABASE_URL` |
| 6 | `src/db/index.ts` sans gestion **SSL** | En production (Neon, Render, Railway, Supabase) : `no pg_hba.conf entry / SSL required` → backend KO | Détection automatique (`sslmode=require`, `DATABASE_SSL`, hôte distant) |
| 7 | `src/db/index.ts` ne chargeait pas `.env` hors Next.js | Impossible d'écrire un script de migration/seed | Chargement `.env.local` puis `.env` en repli |
| 8 | Aucun moyen de savoir **quelle** base l'application utilise | Écart invisible entre l'app et pgAdmin | `npm run db:check` affiche serveur/port/base/rôle + chemin pgAdmin exact |
| 9 | `Dockerfile` copiait `drizzle.config.json` (supprimé) et ne migrait jamais | Image cassée / base non initialisée | Dockerfile corrigé : migration puis démarrage |
| 10 | Base déjà créée avec `push` → `migrate` aurait échoué (`relation already exists`) | Impossible de passer proprement aux migrations | **Baseline automatique** : les migrations sont marquées comme appliquées sans rejouer le SQL, **sans perte de données** |

### Vérification du point « table `services` avec `is_published` et `ordre` »

```
services(id, slug, nom, emoji, accroche, description, image, points, ordre, is_published, created_at)
```

La table **et** ces deux colonnes existent bien dans `src/db/schema.ts`
(`ordre: integer("ordre")`, `isPublished: boolean("is_published")`) et dans
`drizzle/0000_init.sql`. L'erreur `column "is_published" does not exist`
provenait donc d'une **base non migrée** (ou d'une autre base que celle ouverte
dans pgAdmin), pas du code. `npm run db:check` détecte désormais ce cas et liste
précisément les tables/colonnes manquantes.

> Contrôle effectué sur l'ensemble du SQL brut du projet : les colonnes citées par
> les requêtes correspondent au schéma (`payables.montant_total/montant_paye`,
> `commerce_products.stock_min`, `catering_ingredient.quantite`,
> `stock_intrant.valeur_stock`, `produit_intrant.seuil_alerte`…).

---

## 3. Procédure locale (Windows 10 + pgAdmin 4)

```bat
copy .env.example .env
REM DATABASE_URL=postgresql://postgres:MOT_DE_PASSE@localhost:5432/kasayi_erp

npm install
npm run db:create     :: crée la base si absente
npm run db:migrate    :: crée les 74 tables
npm run db:seed       :: données de démonstration (rejouable)
npm run db:check      :: doit afficher « Le schéma PostgreSQL correspond au schéma Drizzle »
npm run dev
```

### Résultat attendu dans pgAdmin 4

1. `Servers → PostgreSQL 16 → Databases → kasayi_erp → Schemas → public → Tables`
2. **74 tables**, dont : `users`, `roles`, `permissions`, `role_permissions`,
   `services`, `faqs`, `articles`, `employees`, `payroll`, `accounts`,
   `transactions`, `commerce_products`, `sales`, `vehicles`, `trips`, `projects`,
   `events`, `parcelle`, `culture`, `recolte`, `vente_agricole`,
   `ai_conversation`, `ai_message`, `ai_setting`…
3. Un schéma supplémentaire **`drizzle`** contenant `__drizzle_migrations`
   (l'historique des migrations appliquées).
4. `SELECT * FROM services;` → 5 lignes, colonnes `ordre` et `is_published` présentes.

> ⚠️ Si pgAdmin n'affiche rien : vous n'êtes pas sur la même base. Comparez avec la
> sortie de `npm run db:check` (« Dans pgAdmin 4, ouvrez EXACTEMENT : … ») et
> pensez à faire un clic droit → **Refresh** sur le nœud *Tables*.

---

## 4. Faire évoluer le schéma (procédure professionnelle)

```bash
# 1. Modifier src/db/schema.ts
# 2. Générer la migration SQL (relisez le fichier créé dans drizzle/)
npm run db:generate
# 3. L'appliquer en local
npm run db:migrate
# 4. Committer schema.ts + drizzle/*.sql + drizzle/meta/*
git add src/db/schema.ts drizzle && git commit -m "feat(db): ..."
# 5. En production : npm run db:migrate (automatique sur Render/Docker/Vercel)
```

`npm run db:push` reste utile pour un prototypage local rapide, **jamais en production**.

---

## 5. Sauvegarde / restauration

```bash
# Sauvegarde (avant toute opération destructive)
pg_dump -U postgres -d kasayi_erp -F c -f sauvegarde_kasayi.dump

# Restauration
pg_restore -U postgres -d kasayi_erp --clean sauvegarde_kasayi.dump
```

`npm run db:reset` **refuse** de s'exécuter sans `-- --force` et rappelle la commande
de sauvegarde : aucune destruction accidentelle possible.
