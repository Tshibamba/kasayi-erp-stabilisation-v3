# KasayiMultiBusiness ERP

ERP multi-activités pour la RD Congo — Agriculture, Commerce, Transport, Sous-traitance, Service traiteur, RH, Comptabilité SYSCOHADA.
Site public multilingue + assistant IA connecté à la base de données.

![Next.js](https://img.shields.io/badge/Next.js-16-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue) ![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15%2B-blue) ![Drizzle](https://img.shields.io/badge/Drizzle-ORM-orange)

---

## 📋 Prérequis

| Logiciel       | Version                 |
| -------------- | ----------------------- |
| **Node.js**    | ≥ 20 LTS (recommandé 22) |
| **PostgreSQL** | ≥ 15 (recommandé 16)     |
| **npm**        | ≥ 10                     |
| **pgAdmin 4**  | optionnel (visualisation)|

---

## 🚀 Installation locale — Windows 10 (5 minutes)

### Méthode automatique (recommandée)

```bat
git clone https://github.com/Tshibamba/kasayimultibusiness-erp-project-context-78-.git
cd kasayimultibusiness-erp-project-context-78-
copy .env.example .env
REM → ouvrez .env et mettez votre mot de passe PostgreSQL dans DATABASE_URL
scripts\setup-windows.bat
```

Le script exécute : `npm install` → création de la base → migrations → seed → diagnostic.

### Méthode manuelle (toutes plateformes)

```bash
# 1. Dépendances
npm install

# 2. Configuration  (Windows : copy .env.example .env)
cp .env.example .env
#    Éditez DATABASE_URL :
#    DATABASE_URL=postgresql://postgres:VOTRE_MOT_DE_PASSE@localhost:5432/kasayi_erp

# 3. Créer la base PostgreSQL si elle n'existe pas
npm run db:create

# 4. Créer les 74 tables (migrations SQL versionnées)
npm run db:migrate

# 5. Charger les données de démonstration (idempotent, aucun doublon)
npm run db:seed

# 6. Vérifier que tout correspond
npm run db:check

# 7. Démarrer
npm run dev
```

> ❗ **Aucune commande `bash` ni `curl` n'est requise.** Tout passe par `npm run`,
> donc PowerShell et CMD fonctionnent nativement.

| URL                                 | Description            |
| ----------------------------------- | ---------------------- |
| http://localhost:3000               | 🌐 Site public          |
| http://localhost:3000/login         | 🔐 Connexion agent ERP  |
| http://localhost:3000/connexion     | 👤 Espace client        |
| http://localhost:3000/dashboard     | 📊 Tableau de bord ERP  |
| http://localhost:3000/api/health    | ❤️ Santé + base         |

**Compte administrateur par défaut** : `admin@kasayimulti.cd` / `admin123` (à changer immédiatement).

---

## 📜 Commandes npm

### Application

| Commande            | Rôle                                   |
| ------------------- | -------------------------------------- |
| `npm run dev`       | Serveur de développement (port 3000)   |
| `npm run build`     | Build de production                    |
| `npm start`         | Serveur de production (après build)    |
| `npm run lint`      | ESLint                                 |
| `npm run typecheck` | Vérification TypeScript                |

### Base de données

| Commande              | Rôle                                                                    |
| --------------------- | ----------------------------------------------------------------------- |
| `npm run db:create`   | Crée la base indiquée dans `DATABASE_URL` si elle n'existe pas          |
| `npm run db:generate` | **Génère** un fichier SQL de migration après modification du schéma     |
| `npm run db:migrate`  | **Applique** les migrations (Node pur — Windows, Docker, hébergeur)     |
| `npm run db:seed`     | Charge les données de démonstration (**idempotent**)                    |
| `npm run db:check`    | **Diagnostic** : compare schéma Drizzle ↔ PostgreSQL, affiche la connexion |
| `npm run db:push`     | Synchronisation directe *(développement uniquement, sans historique)*   |
| `npm run db:studio`   | Interface web Drizzle Studio                                            |
| `npm run db:reset`    | ⚠️ Vide la base (exige `-- --force`, propose la sauvegarde `pg_dump`)    |
| `npm run db:setup`    | `db:create` + `db:migrate` + `db:seed`                                  |
| `npm run setup`       | `npm install` + `db:setup`                                              |

### Quelle commande pour quel usage ?

| Contexte                                    | Commande                    | Pourquoi                                                    |
| ------------------------------------------- | --------------------------- | ----------------------------------------------------------- |
| **Développement** — prototypage rapide      | `npm run db:push`           | Applique le schéma sans créer de fichier SQL                 |
| **Développement** — modification définitive | `db:generate` puis `db:migrate` | Crée un fichier SQL versionné, revu et committé          |
| **Production / hébergeur**                  | `npm run db:migrate`        | Reproductible, transactionnel, journalisé, jamais interactif |

> `drizzle-kit push` ne laisse **aucune trace** de ce qui a été appliqué : c'est la
> cause classique d'une base « à moitié créée ». En production, utilisez toujours
> `db:migrate`.

---

## 🩺 « Mes tables n'apparaissent pas dans pgAdmin 4 »

```bash
npm run db:check
```

Le diagnostic affiche **la connexion réellement utilisée par l'application**
(serveur, port, base, rôle), le chemin exact à ouvrir dans pgAdmin, la liste des
tables manquantes et le nombre de lignes des tables clés.

Détails complets : [`docs/DIAGNOSTIC-BASE-DE-DONNEES.md`](docs/DIAGNOSTIC-BASE-DE-DONNEES.md).

---

## 🌐 Site public

* Design moderne (méga-menu des métiers piloté par la base, hero, sections, footer).
* **Images stockées dans le projet** : `public/images/` — remplacez simplement un
  fichier (`agriculture.jpg`, `commerce.jpg`, `transport.jpg`, `sous-traitance.jpg`,
  `traiteur.jpg`, `equipe.jpg`, `realisations.jpg`, `entrepot.jpg`, `hero.jpg`)
  ou modifiez les URL depuis **Administration → Médias**.
* **Bouton multilingue** dans la barre de menus : 🇫🇷 Français · 🇬🇧 English ·
  🇵🇹 Português · 🇪🇸 Español · 🇨🇳 中文 · 🇨🇩 Kiswahili · 🇨🇩 Lingála
  (choix mémorisé dans un cookie ; ajouter une langue = éditer
  `src/lib/i18n/dictionaries.ts`).

## 🤖 Assistant IA (sur toutes les pages)

| Visiteur                | Capacités                                                                                        |
| ----------------------- | ------------------------------------------------------------------------------------------------ |
| **Public (non connecté)** | Guide sur tout le site : métiers, FAQ, actualités, coordonnées, devis. Contexte lu **en direct dans PostgreSQL**. Aucune donnée financière exposée. |
| **Agent / administrateur** | Rapports **mensuels** et **annuels** par activité, rapport **global**, **bilan** comptable simplifié, **vérification de stock** multi-modules, calculs automatiques, alertes, impayés, rentabilité. |

Exemples de demandes côté ERP :

```
Rapport mensuel de mars 2026
Rapport annuel 2026 agriculture
Rapport complet
Bilan
Vérification de stock
```

Sans clé API, l'assistant répond en **mode local** avec les vraies données SQL.
Avec `GEMINI_API_KEY` (ou OpenAI / Claude / Mistral / OpenRouter / Ollama), ces mêmes
données sont injectées comme contexte factuel dans le modèle.

---

## ☁️ Déploiement

Guide complet : [`DEPLOYMENT.md`](DEPLOYMENT.md).

**Principe universel** : `install` → variables d'environnement → `db:migrate` → (`db:seed`) → `build` → `start`.

```bash
npm ci
# DATABASE_URL + SESSION_SECRET + DATABASE_SSL=true
npm run db:migrate     # crée/actualise les tables sur la base distante
npm run db:seed        # première mise en ligne uniquement (idempotent)
npm run build
npm start
```

* **Render** : `render.yaml` prêt (migration automatique au démarrage).
* **Vercel + Neon** : `vercel.json` exécute la migration avant le build.
* **Docker / VPS** : `docker compose up -d` (le conteneur migre puis démarre).
* **PM2** : `pm2 start ecosystem.config.cjs`.

---

## 📁 Structure

```
├── src/
│   ├── app/(public)/      Site vitrine multilingue
│   ├── app/(erp)/         Back-office ERP
│   ├── app/api/           ~100 routes API
│   ├── components/        UI (dont ai/chat-widget, public/language-switcher)
│   ├── lib/
│   │   ├── ai/            Assistant IA : service, outils ERP, rapports, mode public
│   │   └── i18n/          Dictionnaires + contexte multilingue
│   └── db/
│       ├── schema.ts      Schéma Drizzle — 74 tables (source de vérité)
│       ├── index.ts       Connexion PostgreSQL (SSL auto, pool)
│       ├── seed.ts        Seed idempotent
│       ├── check.ts       Diagnostic
│       ├── create-database.ts / reset.ts
├── drizzle/               Migrations SQL versionnées + journal
├── scripts/
│   ├── migrate.mjs        Migrateur Node pur (Windows/Docker/hébergeur)
│   ├── setup-windows.bat / .ps1
├── public/images/         Images du site (modifiables)
```

---

## 🔐 Sécurité

* Mots de passe hachés (bcrypt), sessions httpOnly signées HMAC-SHA256.
* Blocage après 5 tentatives (15 min), historique des connexions.
* Middleware : toute route financière renvoie 401 sans session agent.
* Le site public et l'assistant public n'exposent aucune donnée financière.

## 📄 Licence

MIT — **KasayiMultiBusiness**, Kananga, Kasaï Central, RD Congo.
