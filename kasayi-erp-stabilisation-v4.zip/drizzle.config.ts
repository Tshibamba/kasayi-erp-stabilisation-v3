import { defineConfig } from "drizzle-kit";
import dotenv from "dotenv";

// .env.local (surcharge locale, non versionnée) puis .env
dotenv.config({ path: ".env.local" });
dotenv.config();

const url = process.env.DATABASE_URL;

if (!url) {
  throw new Error(
    "DATABASE_URL est manquant : copiez .env.example vers .env puis renseignez la connexion PostgreSQL.",
  );
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url,
    // Hébergeurs managés (Neon, Render, Railway, Supabase…) : TLS requis
    ssl: /sslmode=(require|verify-ca|verify-full)/i.test(url) || process.env.DATABASE_SSL === "true"
      ? { rejectUnauthorized: false }
      : undefined,
  },
  migrations: {
    table: "__drizzle_migrations",
    schema: "drizzle",
  },
  verbose: true,
  strict: true,
});
