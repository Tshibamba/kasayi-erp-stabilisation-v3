/**
 * ⚠️  RÉINITIALISATION DESTRUCTIVE — npm run db:reset
 * ─────────────────────────────────────────────────────────────
 * Supprime TOUTES les tables (schéma public + journal drizzle) puis
 * recrée le schéma à partir des migrations et recharge le seed.
 *
 * Sécurité : refuse de s'exécuter sans confirmation explicite.
 *   npm run db:reset -- --force
 *
 * SAUVEGARDE PRÉALABLE recommandée :
 *   pg_dump -U postgres -d kasayi_erp -F c -f sauvegarde_kasayi.dump
 *   (restauration : pg_restore -U postgres -d kasayi_erp sauvegarde_kasayi.dump)
 */
import "dotenv/config";
import { sql } from "drizzle-orm";
import { db, pool, describeConnection } from "./index";

async function main() {
  const force = process.argv.includes("--force") || process.env.DB_RESET_FORCE === "1";
  const conn = describeConnection();

  if (!force) {
    console.log("⚠️  Opération DESTRUCTIVE : toutes les tables de la base");
    console.log(`    « ${conn.database} » (${conn.host}:${conn.port}) seront supprimées.`);
    console.log("");
    console.log("    Sauvegardez d'abord :");
    console.log(`      pg_dump -U ${conn.user} -d ${conn.database} -F c -f sauvegarde_kasayi.dump`);
    console.log("");
    console.log("    Pour confirmer :  npm run db:reset -- --force");
    await pool.end();
    return;
  }

  console.log(`▶ Suppression du schéma public de « ${conn.database} »…`);
  await db.execute(sql`DROP SCHEMA IF EXISTS public CASCADE`);
  await db.execute(sql`CREATE SCHEMA public`);
  await db.execute(sql`DROP SCHEMA IF EXISTS drizzle CASCADE`);
  console.log("✅ Schéma vidé. Lancez maintenant : npm run db:setup");
  await pool.end();
}

main().catch(async (err) => {
  console.error("❌ Reset impossible :", err instanceof Error ? err.message : err);
  await pool.end().catch(() => {});
  process.exit(1);
});
