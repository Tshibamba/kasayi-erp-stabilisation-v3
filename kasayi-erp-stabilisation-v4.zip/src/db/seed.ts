/**
 * ─────────────────────────────────────────────────────────────
 * Seed PostgreSQL — multiplateforme, IDEMPOTENT
 * Commande : npm run db:seed
 * ─────────────────────────────────────────────────────────────
 * Contrairement à l'ancien `scripts/seed.sh` (bash + curl + serveur
 * HTTP démarré), ce script écrit DIRECTEMENT dans PostgreSQL.
 *   • fonctionne sous Windows (PowerShell / CMD) sans bash ni curl ;
 *   • ne nécessite pas que `npm run dev` tourne ;
 *   • réexécutable sans créer de doublons (chaque étape vérifie
 *     l'existence des données avant insertion).
 *
 * La logique métier n'est PAS dupliquée : on réutilise exactement
 * les mêmes fonctions que les routes API /api/setup, /api/seed-*.
 */
import "dotenv/config";
import { pool, describeConnection } from "./index";

import { POST as setupFondations } from "@/app/api/setup/route";
import { POST as initMotsDePasse } from "@/app/api/auth/staff/init/route";
import { POST as seedServices } from "@/app/api/seed-services/route";
import { POST as seedContenu } from "@/app/api/seed-content/route";
import { POST as seedAgriculture } from "@/app/api/agriculture/seed/route";
import { POST as seedProduction } from "@/app/api/agriculture/seed-production/route";
import { POST as seedModules } from "@/app/api/seed-modules/route";
import { POST as seedTransport } from "@/app/api/transport/seed/route";
import { POST as seedSousTraitance } from "@/app/api/sous-traitance/seed/route";
import { POST as seedTraiteur } from "@/app/api/traiteur/seed/route";

type Etape = { titre: string; run: () => Promise<Response> };

const ETAPES: Etape[] = [
  { titre: "Fondations (rôles, permissions, entreprise, taux, utilisateurs)", run: () => setupFondations() as Promise<Response> },
  { titre: "Mots de passe agents (admin123 si non défini)", run: () => initMotsDePasse() as Promise<Response> },
  { titre: "Services & FAQ du site public", run: () => seedServices() as Promise<Response> },
  { titre: "Articles / actualités", run: () => seedContenu() as Promise<Response> },
  { titre: "Agriculture — intrants, fournisseurs, stocks", run: () => seedAgriculture() as Promise<Response> },
  { titre: "Agriculture — parcelles, cultures, récoltes, ventes", run: () => seedProduction() as Promise<Response> },
  { titre: "Modules ERP (RH, comptabilité, commerce, projets…)", run: () => seedModules() as Promise<Response> },
  { titre: "Transport — véhicules, missions, carburant, entretiens", run: () => seedTransport() as Promise<Response> },
  { titre: "Sous-traitance — projets, contrats, factures", run: () => seedSousTraitance() as Promise<Response> },
  { titre: "Traiteur — événements, menus, stock alimentaire", run: () => seedTraiteur() as Promise<Response> },
];

/**
 * Bascule les visuels stockés en base vers les images locales de /public/images.
 * Idempotent : ne touche que les enregistrements pointant encore vers une URL externe.
 */
async function normaliserImages(): Promise<number> {
  const { db } = await import("./index");
  const { sql } = await import("drizzle-orm");
  const parSlug: Record<string, string> = {
    agriculture: "/images/agriculture.jpg",
    commerce: "/images/commerce.jpg",
    transport: "/images/transport.jpg",
    "sous-traitance": "/images/sous-traitance.jpg",
    traiteur: "/images/traiteur.jpg",
  };
  let total = 0;
  for (const [slug, image] of Object.entries(parSlug)) {
    const r = await db.execute(
      sql`UPDATE services SET image = ${image} WHERE slug = ${slug} AND (image IS NULL OR image LIKE 'http%')`,
    );
    total += r.rowCount ?? 0;
  }
  const r2 = await db.execute(
    sql`UPDATE articles SET image = '/images/hero.jpg' WHERE image IS NULL OR image LIKE 'http%'`,
  );
  total += r2.rowCount ?? 0;
  return total;
}

async function main() {
  const conn = describeConnection();
  console.log("─────────────────────────────────────────────");
  console.log("  Seed KasayiMultiBusiness ERP");
  console.log(`  Base : ${conn.database} @ ${conn.host}:${conn.port}`);
  console.log("─────────────────────────────────────────────");

  let erreurs = 0;
  for (const [i, etape] of ETAPES.entries()) {
    const n = `${i + 1}/${ETAPES.length}`;
    try {
      const res = await etape.run();
      const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      if (data.alreadySeeded) {
        console.log(`  ${n} ⏭  ${etape.titre} — déjà présent (aucun doublon créé)`);
      } else if (res.status >= 400 || data.error) {
        erreurs++;
        console.log(`  ${n} ❌ ${etape.titre} — ${String(data.error ?? res.status)}`);
      } else {
        console.log(`  ${n} ✅ ${etape.titre}`);
      }
    } catch (e) {
      erreurs++;
      console.log(`  ${n} ❌ ${etape.titre} — ${e instanceof Error ? e.message : e}`);
    }
  }

  try {
    const n = await normaliserImages();
    console.log(`  11/11 ✅ Images locales (/public/images) — ${n} enregistrement(s) mis à jour`);
  } catch (e) {
    console.log(`  11/11 ⚠  Normalisation des images ignorée — ${e instanceof Error ? e.message : e}`);
  }

  console.log("─────────────────────────────────────────────");
  if (erreurs === 0) {
    console.log("  ✅ Seed terminé sans erreur.");
  } else {
    console.log(`  ⚠  Seed terminé avec ${erreurs} étape(s) en erreur.`);
    console.log("     Vérifiez d'abord les tables : npm run db:check");
  }
  console.log("  Connexion agent : admin@kasayimulti.cd / admin123");
  console.log("  ⚠  Changez ce mot de passe après la première connexion.");
  console.log("─────────────────────────────────────────────");

  await pool.end();
  if (erreurs > 0) process.exit(1);
}

main().catch(async (err) => {
  console.error("❌ Seed impossible :", err instanceof Error ? err.message : err);
  console.error("   Les tables existent-elles ? Lancez d'abord : npm run db:migrate");
  await pool.end().catch(() => {});
  process.exit(1);
});
