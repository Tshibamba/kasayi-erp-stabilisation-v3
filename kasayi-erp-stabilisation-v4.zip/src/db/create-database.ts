/**
 * Crée la base PostgreSQL indiquée dans DATABASE_URL si elle n'existe pas.
 * Commande : npm run db:create
 * Non destructif : si la base existe déjà, rien n'est modifié.
 */
import "dotenv/config";
import { Client } from "pg";

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL manquant (copiez .env.example vers .env).");

  const parsed = new URL(url);
  const dbName = decodeURIComponent(parsed.pathname.replace(/^\//, ""));
  if (!dbName) throw new Error("Aucun nom de base dans DATABASE_URL.");

  // Connexion à la base de maintenance « postgres » du même serveur
  const admin = new URL(url);
  admin.pathname = "/postgres";

  const ssl =
    /sslmode=(require|verify-ca|verify-full)/i.test(url) || process.env.DATABASE_SSL === "true"
      ? { rejectUnauthorized: false }
      : undefined;

  const client = new Client({ connectionString: admin.toString(), ssl });
  await client.connect();
  try {
    const { rows } = await client.query("SELECT 1 FROM pg_database WHERE datname = $1", [dbName]);
    if (rows.length > 0) {
      console.log(`ℹ  La base « ${dbName} » existe déjà sur ${parsed.hostname}:${parsed.port || 5432}.`);
    } else {
      await client.query(`CREATE DATABASE "${dbName.replace(/"/g, '""')}"`);
      console.log(`✅ Base « ${dbName} » créée sur ${parsed.hostname}:${parsed.port || 5432}.`);
    }
    console.log("   Étape suivante : npm run db:migrate");
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error("❌ Création de base impossible :", err instanceof Error ? err.message : err);
  console.error(
    "   • Vérifiez que le service PostgreSQL tourne (Windows : services.msc → postgresql-x64-16)\n" +
      "   • Vérifiez l'utilisateur / mot de passe / port dans DATABASE_URL\n" +
      "   • Vous pouvez aussi créer la base manuellement dans pgAdmin 4 (clic droit sur Databases → Create).",
  );
  process.exit(1);
});
