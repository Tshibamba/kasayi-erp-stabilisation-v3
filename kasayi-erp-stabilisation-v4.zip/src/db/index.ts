/**
 * ─────────────────────────────────────────────────────────────
 * Connexion PostgreSQL (Drizzle ORM · node-postgres)
 * ─────────────────────────────────────────────────────────────
 * Utilisée par :
 *   - Next.js (server components, route handlers)
 *   - les scripts CLI (`npm run db:migrate`, `db:seed`, `db:check`)
 *
 * Next.js charge `.env` / `.env.local` automatiquement, mais pas
 * les scripts Node : on charge donc dotenv de façon défensive.
 */
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";
import * as schema from "./schema";

// Chargement .env pour l'exécution hors Next.js (scripts CLI).
if (!process.env.DATABASE_URL) {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const dotenv = require("dotenv") as typeof import("dotenv");
    dotenv.config({ path: ".env.local" });
    dotenv.config();
  } catch {
    /* dotenv absent en production compilée : ignoré */
  }
}

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error(
    [
      "DATABASE_URL est manquant.",
      "→ Copiez .env.example vers .env puis renseignez la chaîne de connexion PostgreSQL.",
      "  Exemple : DATABASE_URL=postgresql://postgres:motdepasse@localhost:5432/kasayi_erp",
    ].join("\n"),
  );
}

/**
 * SSL : la majorité des hébergeurs (Neon, Render, Railway, Heroku, Supabase…)
 * exigent TLS avec un certificat non vérifiable côté client.
 * - `?sslmode=require` dans l'URL  → SSL activé
 * - `DATABASE_SSL=true`            → SSL activé
 * - localhost / 127.0.0.1          → SSL désactivé (PostgreSQL local Windows)
 */
function resolveSsl(url: string): PoolConfig["ssl"] {
  const forced = (process.env.DATABASE_SSL ?? "").toLowerCase();
  if (forced === "false" || forced === "0" || forced === "disable") return undefined;

  let host = "";
  try {
    host = new URL(url).hostname;
  } catch {
    /* URL non parsable : on retombe sur la détection par mot-clé */
  }
  const isLocal = host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "db" || host === "postgres";
  const wantsSsl =
    forced === "true" ||
    forced === "1" ||
    forced === "require" ||
    /sslmode=(require|verify-ca|verify-full)/i.test(url) ||
    (!isLocal && process.env.NODE_ENV === "production");

  return wantsSsl ? { rejectUnauthorized: false } : undefined;
}

const globalForDb = globalThis as typeof globalThis & {
  __kasayiPgPool?: Pool;
};

export const pool =
  globalForDb.__kasayiPgPool ??
  new Pool({
    connectionString: databaseUrl,
    ssl: resolveSsl(databaseUrl),
    max: Number(process.env.DATABASE_POOL_MAX ?? 10),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: Number(process.env.DATABASE_CONNECT_TIMEOUT_MS ?? 15_000),
  });

// Évite qu'une erreur de socket inactive ne fasse tomber le process Node.
pool.on("error", (err) => {
  console.error("[postgres] erreur de connexion inactive :", err.message);
});

if (process.env.NODE_ENV !== "production") {
  globalForDb.__kasayiPgPool = pool;
}

export const db = drizzle(pool, { schema });

/** Décrit la connexion réelle (utile pour diagnostiquer un écart avec pgAdmin 4). */
export function describeConnection() {
  try {
    const u = new URL(databaseUrl!);
    return {
      host: u.hostname,
      port: u.port || "5432",
      database: u.pathname.replace(/^\//, "") || "(défaut)",
      user: decodeURIComponent(u.username) || "(défaut)",
      ssl: Boolean(resolveSsl(databaseUrl!)),
    };
  } catch {
    return { host: "?", port: "?", database: "?", user: "?", ssl: false };
  }
}
