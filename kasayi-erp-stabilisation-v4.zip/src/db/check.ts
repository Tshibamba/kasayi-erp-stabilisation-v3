/**
 * ─────────────────────────────────────────────────────────────
 * Diagnostic base de données — npm run db:check
 * ─────────────────────────────────────────────────────────────
 * Compare le schéma Drizzle (source de vérité, src/db/schema.ts)
 * avec ce qui existe réellement dans PostgreSQL, et affiche la
 * connexion exacte utilisée par l'application afin de repérer un
 * écart avec ce qui est visible dans pgAdmin 4 (mauvaise base,
 * mauvais serveur, mauvais schéma…).
 */
import "dotenv/config";
import { sql, getTableName, is } from "drizzle-orm";
import { PgTable, getTableConfig } from "drizzle-orm/pg-core";
import { db, pool, describeConnection } from "./index";
import * as schema from "./schema";

type ColonneAttendue = { name: string; notNull: boolean };

function tablesAttendues(): Map<string, ColonneAttendue[]> {
  const map = new Map<string, ColonneAttendue[]>();
  for (const value of Object.values(schema)) {
    if (is(value, PgTable)) {
      const cfg = getTableConfig(value as PgTable);
      map.set(getTableName(value as PgTable), cfg.columns.map((c) => ({ name: c.name, notNull: c.notNull })));
    }
  }
  return new Map([...map.entries()].sort((a, b) => a[0].localeCompare(b[0])));
}

async function main() {
  const conn = describeConnection();
  const attendues = tablesAttendues();

  console.log("═════════════════════════════════════════════════════");
  console.log("  DIAGNOSTIC BASE DE DONNÉES — KasayiMultiBusiness");
  console.log("═════════════════════════════════════════════════════");
  console.log(` Serveur  : ${conn.host}:${conn.port}`);
  console.log(` Base     : ${conn.database}`);
  console.log(` Rôle     : ${conn.user}`);
  console.log(` SSL      : ${conn.ssl ? "activé" : "désactivé"}`);
  console.log("─────────────────────────────────────────────────────");
  console.log(" Dans pgAdmin 4, ouvrez EXACTEMENT :");
  console.log(`   Servers → (serveur ${conn.host}:${conn.port}) → Databases → ${conn.database} → Schemas → public → Tables`);
  console.log("─────────────────────────────────────────────────────");

  const info = await db.execute<{ db: string; schema: string; version: string }>(
    sql`SELECT current_database() AS db, current_schema() AS schema, version() AS version`,
  );
  console.log(` Connexion réelle : base « ${info.rows[0]?.db} », schéma « ${info.rows[0]?.schema} »`);
  console.log(` ${info.rows[0]?.version?.split(",")[0]}`);
  console.log("─────────────────────────────────────────────────────");

  const existantes = await db.execute<{ table_name: string }>(
    sql`SELECT table_name FROM information_schema.tables
        WHERE table_schema = current_schema() AND table_type = 'BASE TABLE'
        ORDER BY table_name`,
  );
  const setExistantes = new Set(existantes.rows.map((r) => r.table_name));

  const manquantes = [...attendues.keys()].filter((t) => !setExistantes.has(t));
  const enTrop = [...setExistantes].filter((t) => !attendues.has(t) && t !== "__drizzle_migrations");

  console.log(` Tables attendues (schéma Drizzle) : ${attendues.size}`);
  console.log(` Tables présentes (PostgreSQL)     : ${setExistantes.size}`);

  // Colonnes manquantes sur les tables existantes
  const colonnesManquantes: string[] = [];
  if (manquantes.length !== attendues.size) {
    const cols = await db.execute<{ table_name: string; column_name: string }>(
      sql`SELECT table_name, column_name FROM information_schema.columns WHERE table_schema = current_schema()`,
    );
    const parTable = new Map<string, Set<string>>();
    for (const r of cols.rows) {
      if (!parTable.has(r.table_name)) parTable.set(r.table_name, new Set());
      parTable.get(r.table_name)!.add(r.column_name);
    }
    for (const [table, colonnes] of attendues) {
      const reelles = parTable.get(table);
      if (!reelles) continue;
      for (const c of colonnes) {
        if (!reelles.has(c.name)) colonnesManquantes.push(`${table}.${c.name}`);
      }
    }
  }

  if (manquantes.length === 0 && colonnesManquantes.length === 0) {
    console.log("\n ✅ Le schéma PostgreSQL correspond au schéma Drizzle.");
  } else {
    if (manquantes.length > 0) {
      console.log(`\n ❌ ${manquantes.length} table(s) MANQUANTE(S) :`);
      console.log("    " + manquantes.join(", "));
    }
    if (colonnesManquantes.length > 0) {
      console.log(`\n ❌ ${colonnesManquantes.length} colonne(s) MANQUANTE(S) :`);
      console.log("    " + colonnesManquantes.join(", "));
    }
    console.log("\n → Correction : npm run db:migrate   (puis npm run db:seed)");
  }

  if (enTrop.length > 0) {
    console.log(`\n ℹ  ${enTrop.length} table(s) présente(s) en base mais absente(s) du schéma Drizzle :`);
    console.log("    " + enTrop.join(", "));
    console.log("    (aucune suppression automatique n'est effectuée)");
  }

  // Journal de migration
  const journal = await db
    .execute<{ hash: string; created_at: string }>(
      sql`SELECT hash, created_at FROM drizzle.__drizzle_migrations ORDER BY created_at`,
    )
    .catch(() => null);
  console.log("─────────────────────────────────────────────────────");
  if (!journal) {
    console.log(" Journal de migration : ABSENT (base créée via `drizzle-kit push` ou base vide)");
  } else {
    console.log(` Journal de migration : ${journal.rows.length} migration(s) appliquée(s)`);
  }

  // Données présentes (les tables clés)
  const clefs = ["users", "roles", "services", "faqs", "articles", "employees", "vehicles", "projects", "commerce_products"];
  console.log("─────────────────────────────────────────────────────");
  console.log(" Données :");
  for (const t of clefs) {
    if (!setExistantes.has(t)) {
      console.log(`   ${t.padEnd(20)} — table absente`);
      continue;
    }
    const r = await db
      .execute<{ n: number }>(sql`SELECT count(*)::int AS n FROM ${sql.identifier(t)}`)
      .catch(() => null);
    console.log(`   ${t.padEnd(20)} ${r?.rows[0]?.n ?? "?"} ligne(s)`);
  }
  console.log("═════════════════════════════════════════════════════");

  await pool.end();
  if (manquantes.length > 0 || colonnesManquantes.length > 0) process.exit(1);
}

main().catch(async (err) => {
  console.error("❌ Diagnostic impossible :", err instanceof Error ? err.message : err);
  console.error("   PostgreSQL est-il démarré et DATABASE_URL correct ?");
  await pool.end().catch(() => {});
  process.exit(1);
});
