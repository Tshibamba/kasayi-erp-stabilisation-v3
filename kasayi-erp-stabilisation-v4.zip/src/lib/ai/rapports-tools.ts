// ─────────────────────────────────────────────────────────────
// Outils IA — Rapports automatiques (mensuels, annuels, bilan, stock)
// Réutilise la logique métier existante (src/lib/bilan.ts, rapports.ts)
// → aucune duplication de calcul
// ─────────────────────────────────────────────────────────────

import { db } from "@/db";
import { sql } from "drizzle-orm";
import { getBilanGlobal, getEvolutionMensuelle, type BilanService } from "@/lib/bilan";
import { getRapportGlobal } from "@/lib/rapports";
import { toNum } from "@/lib/format";

type ToolResult = { text: string; data?: unknown };

const MOIS = [
  "janvier", "février", "mars", "avril", "mai", "juin",
  "juillet", "août", "septembre", "octobre", "novembre", "décembre",
];

const fmt = (n: number) => new Intl.NumberFormat("fr-CD").format(Math.round(n));
const pct = (num: number, den: number) => (den > 0 ? `${((num / den) * 100).toFixed(1)} %` : "—");

/**
 * Dernière période contenant réellement des données (toutes activités).
 * Évite d'afficher un rapport vide lorsque l'exercice en cours n'a pas
 * encore de mouvements (ex. base fraîchement installée).
 */
export async function periodeActive(): Promise<{ annee: number; mois: number }> {
  const maintenant = new Date();
  const r = await db
    .execute<{ annee: number | null; mois: number | null }>(sql`
      WITH d AS (
        SELECT MAX(date) AS d FROM vente_agricole
        UNION ALL SELECT MAX(date) FROM sales
        UNION ALL SELECT MAX(created_at) FROM trips
        UNION ALL SELECT MAX(date_evenement) FROM events
        UNION ALL SELECT MAX(date) FROM project_payment
      )
      SELECT EXTRACT(YEAR FROM MAX(d))::int AS annee,
             EXTRACT(MONTH FROM MAX(d))::int AS mois
      FROM d
    `)
    .catch(() => null);
  const annee = r?.rows[0]?.annee ?? null;
  const mois = r?.rows[0]?.mois ?? null;
  if (!annee) return { annee: maintenant.getFullYear(), mois: maintenant.getMonth() + 1 };
  if (annee >= maintenant.getFullYear()) return { annee: maintenant.getFullYear(), mois: maintenant.getMonth() + 1 };
  return { annee, mois: mois ?? 12 };
}

/** Extrait { mois, annee, activite } d'une question en langage naturel. */
export function analyserPeriode(question: string): {
  mois: number | null;
  annee: number;
  activite: string | null;
  anneeExplicite: boolean;
  moisExplicite: boolean;
} {
  const q = question.toLowerCase();
  const maintenant = new Date();

  const anneeMatch = q.match(/\b(20\d{2})\b/);
  const annee = anneeMatch ? Number(anneeMatch[1]) : maintenant.getFullYear();

  let mois: number | null = null;
  let moisExplicite = false;
  for (let i = 0; i < MOIS.length; i++) {
    const nom = MOIS[i].normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (q.normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(nom)) {
      mois = i + 1;
      moisExplicite = true;
      break;
    }
  }
  if (mois === null && /mensuel|du mois|ce mois|mois en cours/.test(q)) mois = maintenant.getMonth() + 1;
  if (/annuel|de l'ann|annee|année/.test(q) && !/mensuel/.test(q)) mois = null;

  let activite: string | null = null;
  if (/agricol|agriculture|champ|culture|r.colte/.test(q)) activite = "Agriculture";
  else if (/commerce|boutique|magasin|vente/.test(q)) activite = "Commerce";
  else if (/transport|v.hicule|camion|mission/.test(q)) activite = "Transport";
  else if (/sous.?trait|chantier|projet/.test(q)) activite = "Sous-traitance";
  else if (/traiteur|.v.nement|banquet|menu/.test(q)) activite = "Traiteur";

  return { mois, annee, activite, anneeExplicite: Boolean(anneeMatch), moisExplicite };
}

function tableauServices(services: BilanService[]): string {
  const lignes = services
    .map(
      (s) =>
        `| ${s.emoji} ${s.service} | ${fmt(s.recettes)} | ${fmt(s.depenses)} | **${fmt(s.benefice)}** | ${
          s.recettes > 0 ? `${((s.benefice / s.recettes) * 100).toFixed(1)} %` : "—"
        } |`,
    )
    .join("\n");
  return `| Activité | Recettes (CDF) | Dépenses (CDF) | Résultat | Marge |\n|---|---:|---:|---:|---:|\n${lignes}`;
}

// ── Rapport MENSUEL (une activité ou toutes) ─────────────────
export async function toolRapportMensuel(mois: number, annee: number, activite?: string | null): Promise<ToolResult> {
  const bilan = await getBilanGlobal(annee, mois);
  const services = activite
    ? bilan.services.filter((s) => s.service.toLowerCase().includes(activite.toLowerCase()))
    : bilan.services;

  if (services.length === 0) {
    return { text: `Aucune donnée pour « ${activite} » en ${MOIS[mois - 1]} ${annee}.` };
  }

  const recettes = services.reduce((s, x) => s + x.recettes, 0);
  const depenses = services.reduce((s, x) => s + x.depenses, 0);
  const resultat = recettes - depenses;
  const tva = recettes * 0.16;
  const meilleure = [...services].sort((a, b) => b.benefice - a.benefice)[0];

  const titre = activite
    ? `📊 Rapport mensuel — ${activite} — ${MOIS[mois - 1]} ${annee}`
    : `📊 Rapport mensuel GLOBAL — ${MOIS[mois - 1]} ${annee}`;

  const text = [
    `## ${titre}`,
    "",
    tableauServices(services),
    "",
    "### Synthèse",
    `- **Total recettes** : ${fmt(recettes)} CDF`,
    `- **Total dépenses** : ${fmt(depenses)} CDF`,
    `- **Résultat net** : ${fmt(resultat)} CDF ${resultat >= 0 ? "✅ bénéficiaire" : "⚠️ déficitaire"}`,
    `- **Marge nette** : ${pct(resultat, recettes)}`,
    `- **TVA collectée estimée (16 %)** : ${fmt(tva)} CDF`,
    meilleure ? `- **Activité la plus performante** : ${meilleure.emoji} ${meilleure.service} (${fmt(meilleure.benefice)} CDF)` : "",
    "",
    `*Rapport calculé automatiquement depuis PostgreSQL le ${new Date().toLocaleString("fr-FR")}. Export PDF/Excel : module Bilan financier.*`,
  ]
    .filter(Boolean)
    .join("\n");

  return { text, data: { mois, annee, services, recettes, depenses, resultat } };
}

// ── Rapport ANNUEL (une activité ou toutes) ──────────────────
export async function toolRapportAnnuel(annee: number, activite?: string | null): Promise<ToolResult> {
  const [bilan, evolution] = await Promise.all([getBilanGlobal(annee), getEvolutionMensuelle(annee)]);
  const services = activite
    ? bilan.services.filter((s) => s.service.toLowerCase().includes(activite.toLowerCase()))
    : bilan.services;

  const recettes = services.reduce((s, x) => s + x.recettes, 0);
  const depenses = services.reduce((s, x) => s + x.depenses, 0);
  const resultat = recettes - depenses;

  const moisActifs = evolution.filter((m) => m.recettes > 0 || m.depenses > 0);
  const meilleurMois = [...moisActifs].sort((a, b) => b.benefice - a.benefice)[0];
  const pireMois = [...moisActifs].sort((a, b) => a.benefice - b.benefice)[0];

  const lignesMois = evolution
    .map((m) => `| ${m.mois} | ${fmt(m.recettes)} | ${fmt(m.depenses)} | ${fmt(m.benefice)} |`)
    .join("\n");

  const titre = activite ? `📅 Rapport annuel — ${activite} — ${annee}` : `📅 Rapport annuel GLOBAL — ${annee}`;

  const text = [
    `## ${titre}`,
    "",
    "### Par activité",
    tableauServices(services),
    "",
    "### Évolution mensuelle (toutes activités)",
    `| Mois | Recettes | Dépenses | Résultat |\n|---|---:|---:|---:|\n${lignesMois}`,
    "",
    "### Synthèse annuelle",
    `- **Total recettes** : ${fmt(recettes)} CDF`,
    `- **Total dépenses** : ${fmt(depenses)} CDF`,
    `- **Résultat net** : ${fmt(resultat)} CDF ${resultat >= 0 ? "✅" : "⚠️"}`,
    `- **Marge nette** : ${pct(resultat, recettes)}`,
    `- **Moyenne mensuelle des recettes** : ${fmt(recettes / 12)} CDF`,
    meilleurMois ? `- **Meilleur mois** : ${meilleurMois.mois} (${fmt(meilleurMois.benefice)} CDF)` : "",
    pireMois && pireMois !== meilleurMois ? `- **Mois le plus faible** : ${pireMois.mois} (${fmt(pireMois.benefice)} CDF)` : "",
    "",
    `*Généré automatiquement le ${new Date().toLocaleString("fr-FR")} — données temps réel PostgreSQL.*`,
  ]
    .filter(Boolean)
    .join("\n");

  return { text, data: { annee, services, evolution, recettes, depenses, resultat } };
}

// ── BILAN comptable simplifié (inspiration SYSCOHADA) ────────
export async function toolBilanComptable(annee: number): Promise<ToolResult> {
  const [bilan, global] = await Promise.all([getBilanGlobal(annee), getRapportGlobal()]);

  const dettes = await db
    .execute<{ total: string }>(sql`SELECT COALESCE(SUM(GREATEST(montant_total - COALESCE(montant_paye, 0), 0)), 0)::text AS total FROM payables WHERE statut <> 'PAYEE'`)
    .catch(() => null);
  const totalDettes = toNum(dettes?.rows[0]?.total ?? 0);

  const actifCirculant = global.agriValeur + global.commerceValeur + global.creances;
  const tresorerie = global.tresorerie;
  const immobilisations = global.flotteValeur;
  const totalActif = immobilisations + actifCirculant + tresorerie;
  const resultat = bilan.beneficeNet;
  const capitauxPropres = totalActif - totalDettes;

  const text = [
    `## 🧾 Bilan comptable simplifié — exercice ${annee}`,
    "",
    "### ACTIF",
    "| Poste | Montant (CDF) |",
    "|---|---:|",
    `| Immobilisations (flotte, matériel) | ${fmt(immobilisations)} |`,
    `| Stocks (intrants + marchandises) | ${fmt(global.agriValeur + global.commerceValeur)} |`,
    `| Créances clients | ${fmt(global.creances)} |`,
    `| Trésorerie (caisses + banques) | ${fmt(tresorerie)} |`,
    `| **TOTAL ACTIF** | **${fmt(totalActif)}** |`,
    "",
    "### PASSIF",
    "| Poste | Montant (CDF) |",
    "|---|---:|",
    `| Capitaux propres (estimation) | ${fmt(capitauxPropres)} |`,
    `| Dettes fournisseurs / à payer | ${fmt(totalDettes)} |`,
    `| **TOTAL PASSIF** | **${fmt(totalActif)}** |`,
    "",
    "### COMPTE DE RÉSULTAT",
    `- Produits : **${fmt(bilan.totalRecettes)} CDF**`,
    `- Charges : **${fmt(bilan.totalDepenses)} CDF**`,
    `- **Résultat net : ${fmt(resultat)} CDF** ${resultat >= 0 ? "✅ bénéfice" : "⚠️ perte"}`,
    "",
    "### Indicateurs",
    `- Marge nette : ${pct(resultat, bilan.totalRecettes)}`,
    `- Ratio d'endettement : ${pct(totalDettes, totalActif)}`,
    `- Effectif : ${global.effectif} employé(s) · masse salariale ${fmt(global.masseSalariale)} CDF`,
    "",
    "*Bilan indicatif calculé en temps réel. Pour l'export officiel : Pilotage → Bilan financier → PDF / Excel.*",
  ].join("\n");

  return { text, data: { totalActif, totalDettes, resultat } };
}

// ── VÉRIFICATION DE STOCK (multi-modules) ────────────────────
export async function toolVerificationStock(): Promise<ToolResult> {
  const intrants = await db
    .execute<{ produit: string; quantite: string; seuil: string; valeur: string; statut: string }>(sql`
      SELECT p.nom AS produit,
             s.quantite::text AS quantite,
             COALESCE(p.seuil_alerte, 0)::text AS seuil,
             s.valeur_stock::text AS valeur,
             CASE
               WHEN s.quantite <= 0 THEN 'RUPTURE'
               WHEN s.quantite <= COALESCE(p.seuil_alerte, 0) THEN 'CRITIQUE'
               WHEN s.quantite <= COALESCE(p.seuil_alerte, 0) * 1.5 THEN 'FAIBLE'
               ELSE 'OK'
             END AS statut
      FROM stock_intrant s
      JOIN produit_intrant p ON p.id = s.produit_id
      ORDER BY s.quantite ASC
    `)
    .catch(() => null);

  const commerce = await db
    .execute<{ nom: string; stock: string; seuil: string }>(sql`
      SELECT nom, stock::text AS stock, COALESCE(stock_min, 0)::text AS seuil
      FROM commerce_products
      WHERE stock <= COALESCE(stock_min, 0) * 1.5
      ORDER BY stock ASC
    `)
    .catch(() => null);

  const traiteur = await db
    .execute<{ nom: string; quantite: string; unite: string }>(sql`
      SELECT nom, quantite::text AS quantite, unite
      FROM catering_ingredient
      WHERE quantite <= COALESCE(seuil_alerte, 5)
      ORDER BY quantite ASC
    `)
    .catch(() => null);

  const lignes = intrants?.rows ?? [];
  const ruptures = lignes.filter((l) => l.statut === "RUPTURE");
  const critiques = lignes.filter((l) => l.statut === "CRITIQUE");
  const faibles = lignes.filter((l) => l.statut === "FAIBLE");
  const valeurTotale = lignes.reduce((s, l) => s + toNum(l.valeur), 0);

  const bloc = (titre: string, rows: typeof lignes) =>
    rows.length === 0
      ? ""
      : `\n**${titre}**\n\n| Produit | Quantité | Seuil |\n|---|---:|---:|\n${rows
          .map((r) => `| ${r.produit} | ${fmt(toNum(r.quantite))} | ${fmt(toNum(r.seuil))} |`)
          .join("\n")}\n`;

  const text = [
    "## 📦 Vérification automatique des stocks",
    "",
    `- Références suivies (intrants agricoles) : **${lignes.length}**`,
    `- Valeur totale du stock intrants (CMUP) : **${fmt(valeurTotale)} CDF**`,
    `- 🔴 Ruptures : **${ruptures.length}** · 🟠 Critiques : **${critiques.length}** · 🟡 Faibles : **${faibles.length}**`,
    bloc("🔴 En rupture — réapprovisionnement immédiat", ruptures),
    bloc("🟠 Seuil critique atteint", critiques),
    bloc("🟡 Stock faible à surveiller", faibles),
    commerce && commerce.rows.length > 0
      ? `\n**🛒 Commerce — articles sous le seuil**\n\n| Article | Stock | Seuil |\n|---|---:|---:|\n${commerce.rows
          .map((r) => `| ${r.nom} | ${fmt(toNum(r.stock))} | ${fmt(toNum(r.seuil))} |`)
          .join("\n")}\n`
      : "",
    traiteur && traiteur.rows.length > 0
      ? `\n**🍽️ Traiteur — ingrédients à réapprovisionner**\n\n| Ingrédient | Quantité |\n|---|---:|\n${traiteur.rows
          .map((r) => `| ${r.nom} | ${fmt(toNum(r.quantite))} ${r.unite ?? ""} |`)
          .join("\n")}\n`
      : "",
    ruptures.length + critiques.length === 0
      ? "\n✅ Aucun réapprovisionnement urgent détecté."
      : "\n➡️ **Action recommandée** : générer les bons de commande pour les articles en rupture et critiques.",
  ]
    .filter(Boolean)
    .join("\n");

  return { text, data: { ruptures: ruptures.length, critiques: critiques.length, valeurTotale } };
}

// ── Rapport COMPLET (global mensuel + annuel + bilan + stock) ─
export async function toolRapportComplet(annee: number, mois: number): Promise<ToolResult> {
  const [mensuel, annuel, bilan, stock] = await Promise.all([
    toolRapportMensuel(mois, annee),
    toolRapportAnnuel(annee),
    toolBilanComptable(annee),
    toolVerificationStock(),
  ]);
  return {
    text: [
      `# 📚 Rapport complet KasayiMultiBusiness — ${MOIS[mois - 1]} ${annee}`,
      "",
      mensuel.text,
      "\n---\n",
      annuel.text,
      "\n---\n",
      bilan.text,
      "\n---\n",
      stock.text,
    ].join("\n"),
  };
}
