// ─────────────────────────────────────────────────────────────
// Assistant IA PUBLIC (visiteurs non connectés)
// ─────────────────────────────────────────────────────────────
// Connecté au back-end : le contexte est construit en direct depuis
// PostgreSQL (services publiés, FAQ, actualités, coordonnées).
// ⚠️ AUCUNE donnée financière ou interne n'est exposée.

import { db } from "@/db";
import { articles, companySettings, faqs, services } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { createProvider } from "./providers";
import { PROVIDERS, type AIProviderName, type ChatMessage } from "./types";
import { CONSIGNE_LANGUE, LANGUE_DEFAUT, type Langue } from "@/lib/i18n/dictionaries";
import { getAIConfig } from "./service";

export type ReponsePublique = { content: string; provider: AIProviderName | "local" };

type ContextePublic = {
  entreprise: { nom: string; slogan: string | null; adresse: string | null; ville: string | null; telephone: string | null; email: string | null } | null;
  services: { slug: string; nom: string; accroche: string | null; description: string | null; points: unknown }[];
  faqs: { question: string; reponse: string; categorie: string | null }[];
  articles: { titre: string; slug: string; resume: string | null }[];
};

async function chargerContexte(): Promise<ContextePublic> {
  const [entreprise, listeServices, listeFaqs, listeArticles] = await Promise.all([
    db.select().from(companySettings).limit(1).catch(() => []),
    db
      .select({ slug: services.slug, nom: services.nom, accroche: services.accroche, description: services.description, points: services.points })
      .from(services)
      .where(eq(services.isPublished, true))
      .catch(() => []),
    db.select({ question: faqs.question, reponse: faqs.reponse, categorie: faqs.categorie }).from(faqs).catch(() => []),
    db
      .select({ titre: articles.titre, slug: articles.slug, resume: articles.extrait })
      .from(articles)
      .where(and(eq(articles.isPublished, true)))
      .orderBy(desc(articles.publishedAt))
      .limit(5)
      .catch(() => []),
  ]);

  const e = entreprise[0];
  return {
    entreprise: e
      ? { nom: e.nom, slogan: e.slogan, adresse: e.adresse, ville: e.ville, telephone: e.telephone, email: e.email }
      : null,
    services: listeServices,
    faqs: listeFaqs,
    articles: listeArticles,
  };
}

function construirePrompt(ctx: ContextePublic, langue: Langue): string {
  const e = ctx.entreprise;
  return [
    "Tu es l'assistant virtuel du site public de KasayiMultiBusiness, entreprise multi-activités basée au Kasaï Central (Kananga), RD Congo.",
    "Ton rôle : accueillir, guider et orienter les visiteurs sur le site, expliquer les métiers, aider à demander un devis ou à contacter l'entreprise.",
    "RÈGLES STRICTES :",
    "- Ne divulgue JAMAIS de données financières, comptables, RH ou internes (chiffre d'affaires, salaires, stocks, marges).",
    "- Si on te demande ce type d'information, réponds que c'est réservé aux agents connectés à l'espace ERP.",
    "- Reste concis (5 à 10 lignes), chaleureux et professionnel. Utilise le Markdown.",
    "- Termine si possible par une action utile (page à visiter, formulaire de contact, devis).",
    CONSIGNE_LANGUE[langue] ?? CONSIGNE_LANGUE[LANGUE_DEFAUT],
    "",
    "── INFORMATIONS OFFICIELLES (base de données du site) ──",
    e ? `Entreprise : ${e.nom}${e.slogan ? ` — ${e.slogan}` : ""}` : "Entreprise : KasayiMultiBusiness",
    e?.adresse || e?.ville ? `Adresse : ${[e?.adresse, e?.ville].filter(Boolean).join(", ")}` : "",
    e?.telephone ? `Téléphone : ${e.telephone}` : "",
    e?.email ? `Email : ${e.email}` : "",
    "",
    "Métiers publiés :",
    ...ctx.services.map((s) => `- ${s.nom} (/activites#${s.slug}) : ${s.accroche ?? ""} ${s.description ?? ""}`),
    "",
    "FAQ officielle :",
    ...ctx.faqs.map((f) => `- Q: ${f.question}\n  R: ${f.reponse}`),
    "",
    "Dernières actualités :",
    ...ctx.articles.map((a) => `- ${a.titre} (/actualites/${a.slug})`),
    "",
    "Pages du site : / (accueil), /activites, /realisations, /equipe, /flotte, /actualites, /a-propos, /aide, /contact, /connexion (espace client), /login (espace agent).",
  ]
    .filter(Boolean)
    .join("\n");
}

/** Réponse hors-ligne (aucune clé API) : recherche dans la FAQ et les services. */
function reponseLocale(question: string, ctx: ContextePublic): string {
  const q = question
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  if (/bonjour|salut|hello|bonsoir|hi |mbote|jambo|ola|hola|你好/.test(q)) {
    return [
      `👋 Bienvenue chez **${ctx.entreprise?.nom ?? "KasayiMultiBusiness"}** !`,
      "",
      "Je peux vous guider sur :",
      ...ctx.services.slice(0, 6).map((s) => `- **${s.nom}** → [/activites#${s.slug}](/activites#${s.slug})`),
      "",
      "Posez-moi une question, ou demandez **un devis** 👉 [/contact](/contact)",
    ].join("\n");
  }

  const mots = q.split(/[^a-z0-9]+/).filter((m) => m.length > 3);
  const score = (texte: string) => {
    const t = texte.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    return mots.reduce((s, m) => s + (t.includes(m) ? 1 : 0), 0);
  };

  const meilleureFaq = [...ctx.faqs].map((f) => ({ f, s: score(f.question + " " + f.reponse) })).sort((a, b) => b.s - a.s)[0];
  if (meilleureFaq && meilleureFaq.s >= 1) {
    return `**${meilleureFaq.f.question}**\n\n${meilleureFaq.f.reponse}\n\n👉 Plus de réponses : [/aide](/aide)`;
  }

  const meilleurService = [...ctx.services]
    .map((s) => ({ s, sc: score(`${s.nom} ${s.accroche ?? ""} ${s.description ?? ""}`) }))
    .sort((a, b) => b.sc - a.sc)[0];
  if (meilleurService && meilleurService.sc >= 1) {
    const s = meilleurService.s;
    return `### ${s.nom}\n\n${s.description ?? s.accroche ?? ""}\n\n👉 En savoir plus : [/activites#${s.slug}](/activites#${s.slug}) · Devis : [/contact](/contact)`;
  }

  if (/contact|telephone|email|adresse|joindre|ou etes|localis/.test(q)) {
    const e = ctx.entreprise;
    return [
      "### 📍 Nous contacter",
      e?.adresse ? `- Adresse : ${e.adresse}${e.ville ? `, ${e.ville}` : ""}` : "- Kananga, Kasaï Central, RD Congo",
      e?.telephone ? `- Téléphone : ${e.telephone}` : "",
      e?.email ? `- Email : ${e.email}` : "",
      "",
      "👉 Formulaire : [/contact](/contact)",
    ]
      .filter(Boolean)
      .join("\n");
  }

  return [
    "Je n'ai pas trouvé de réponse précise. Voici ce que je peux faire :",
    "",
    ...ctx.services.slice(0, 6).map((s) => `- Présenter **${s.nom}**`),
    "- Expliquer comment demander un **devis**",
    "- Donner nos **coordonnées**",
    "",
    "👉 Vous pouvez aussi écrire directement via [/contact](/contact).",
  ].join("\n");
}

export async function chatPublic(messages: ChatMessage[], langue: Langue = LANGUE_DEFAUT): Promise<ReponsePublique> {
  const question = messages.filter((m) => m.role === "user").pop()?.content ?? "";
  const ctx = await chargerContexte();

  let config: Awaited<ReturnType<typeof getAIConfig>>;
  try {
    config = await getAIConfig();
  } catch {
    return { content: reponseLocale(question, ctx), provider: "local" };
  }

  const apiKey = process.env[PROVIDERS[config.provider].apiKeyEnv] || "";
  if (!apiKey && config.provider !== "ollama") {
    return { content: reponseLocale(question, ctx), provider: "local" };
  }

  try {
    const provider = createProvider(config.provider, apiKey, config.model);
    const result = await provider.chat(
      [{ role: "system", content: construirePrompt(ctx, langue) }, ...messages.slice(-8)],
      { temperature: 0.6, maxTokens: 1200 },
    );
    return { content: result.content, provider: config.provider };
  } catch {
    return { content: reponseLocale(question, ctx), provider: "local" };
  }
}
