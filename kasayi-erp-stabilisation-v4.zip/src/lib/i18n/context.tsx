"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  COOKIE_LANGUE,
  DICTIONNAIRES,
  LANGUE_DEFAUT,
  LANGUES,
  type CleTraduction,
  type Langue,
} from "./dictionaries";

type I18nContexte = {
  langue: Langue;
  setLangue: (l: Langue) => void;
  t: (cle: CleTraduction) => string;
};

const Contexte = createContext<I18nContexte>({
  langue: LANGUE_DEFAUT,
  setLangue: () => {},
  t: (cle) => DICTIONNAIRES[LANGUE_DEFAUT][cle] ?? cle,
});

const CODES = LANGUES.map((l) => l.code) as readonly string[];

function lireCookie(): Langue | null {
  if (typeof document === "undefined") return null;
  const m = document.cookie.match(new RegExp(`(?:^|; )${COOKIE_LANGUE}=([^;]*)`));
  const val = m ? decodeURIComponent(m[1]) : null;
  return val && CODES.includes(val) ? (val as Langue) : null;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [langue, setLangueState] = useState<Langue>(LANGUE_DEFAUT);

  // Hydratation : cookie → langue du navigateur → français
  useEffect(() => {
    const depuisCookie = lireCookie();
    if (depuisCookie) {
      setLangueState(depuisCookie);
      return;
    }
    const nav = (navigator.language || "fr").slice(0, 2).toLowerCase();
    if (CODES.includes(nav)) setLangueState(nav as Langue);
  }, []);

  useEffect(() => {
    document.documentElement.lang = langue;
  }, [langue]);

  const setLangue = useCallback((l: Langue) => {
    setLangueState(l);
    document.cookie = `${COOKIE_LANGUE}=${l}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
  }, []);

  const t = useCallback(
    (cle: CleTraduction) => DICTIONNAIRES[langue]?.[cle] ?? DICTIONNAIRES[LANGUE_DEFAUT][cle] ?? cle,
    [langue],
  );

  const valeur = useMemo(() => ({ langue, setLangue, t }), [langue, setLangue, t]);
  return <Contexte.Provider value={valeur}>{children}</Contexte.Provider>;
}

export function useI18n() {
  return useContext(Contexte);
}
