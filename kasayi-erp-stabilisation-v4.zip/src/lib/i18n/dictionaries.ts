/**
 * ─────────────────────────────────────────────────────────────
 * Internationalisation du site public
 * ─────────────────────────────────────────────────────────────
 * Ajouter une langue = ajouter une entrée dans LANGUES puis un bloc
 * de traductions dans DICTIONNAIRES. Aucune autre modification requise.
 */

export const LANGUES = [
  { code: "fr", label: "Français", drapeau: "🇫🇷" },
  { code: "en", label: "English", drapeau: "🇬🇧" },
  { code: "es", label: "Español", drapeau: "🇪🇸" },
  { code: "pt", label: "Português", drapeau: "🇵🇹" },
  { code: "zh", label: "中文", drapeau: "🇨🇳" },
] as const;

export type Langue = (typeof LANGUES)[number]["code"];
export const LANGUE_DEFAUT: Langue = "fr";
export const COOKIE_LANGUE = "kmb_lang";

export type CleTraduction =
  | "nav.accueil"
  | "nav.metiers"
  | "nav.realisations"
  | "nav.equipe"
  | "nav.flotte"
  | "nav.actualites"
  | "nav.apropos"
  | "nav.aide"
  | "nav.contact"
  | "nav.toutesActivites"
  | "cta.connexion"
  | "cta.monCompte"
  | "cta.espaceAgent"
  | "cta.devis"
  | "cta.decouvrir"
  | "cta.contactez"
  | "cta.envoyer"
  | "langue.titre"
  | "footer.suivez"
  | "footer.droits"
  | "footer.liens"
  | "footer.metiers"
  | "footer.contact"
  | "footer.newsletter"
  | "footer.newsletterTexte"
  | "ia.titre"
  | "ia.sousTitre"
  | "ia.placeholder"
  | "ia.bienvenue"
  | "ia.suggestion1"
  | "ia.suggestion2"
  | "ia.suggestion3"
  | "ia.envoyer"
  | "ia.effacer"
  | "ia.erreur"
  | "commun.chargement"
  | "commun.enSavoirPlus";

type Dico = Record<CleTraduction, string>;

const fr: Dico = {
  "nav.accueil": "Accueil",
  "nav.metiers": "Nos métiers",
  "nav.realisations": "Réalisations",
  "nav.equipe": "Équipe",
  "nav.flotte": "Flotte",
  "nav.actualites": "Actualités",
  "nav.apropos": "À propos",
  "nav.aide": "Aide",
  "nav.contact": "Contact",
  "nav.toutesActivites": "Voir toutes nos activités",
  "cta.connexion": "Connexion",
  "cta.monCompte": "Mon compte",
  "cta.espaceAgent": "Espace agent",
  "cta.devis": "Demander un devis",
  "cta.decouvrir": "Découvrir",
  "cta.contactez": "Contactez-nous",
  "cta.envoyer": "Envoyer",
  "langue.titre": "Langue",
  "footer.suivez": "Suivez-nous",
  "footer.droits": "Tous droits réservés.",
  "footer.liens": "Liens utiles",
  "footer.metiers": "Nos métiers",
  "footer.contact": "Contact",
  "footer.newsletter": "Newsletter",
  "footer.newsletterTexte": "Recevez nos actualités et opportunités.",
  "ia.titre": "Assistant IA",
  "ia.sousTitre": "Votre guide sur tout le site",
  "ia.placeholder": "Posez votre question…",
  "ia.bienvenue": "Bonjour ! Je suis l'assistant de KasayiMultiBusiness. Comment puis-je vous aider ?",
  "ia.suggestion1": "Quels sont vos métiers ?",
  "ia.suggestion2": "Comment demander un devis ?",
  "ia.suggestion3": "Où êtes-vous situés ?",
  "ia.envoyer": "Envoyer",
  "ia.effacer": "Nouvelle conversation",
  "ia.erreur": "Une erreur est survenue. Réessayez.",
  "commun.chargement": "Chargement…",
  "commun.enSavoirPlus": "En savoir plus",
};

const en: Dico = {
  "nav.accueil": "Home",
  "nav.metiers": "Our business lines",
  "nav.realisations": "Achievements",
  "nav.equipe": "Team",
  "nav.flotte": "Fleet",
  "nav.actualites": "News",
  "nav.apropos": "About",
  "nav.aide": "Help",
  "nav.contact": "Contact",
  "nav.toutesActivites": "See all our activities",
  "cta.connexion": "Sign in",
  "cta.monCompte": "My account",
  "cta.espaceAgent": "Staff area",
  "cta.devis": "Request a quote",
  "cta.decouvrir": "Discover",
  "cta.contactez": "Contact us",
  "cta.envoyer": "Send",
  "langue.titre": "Language",
  "footer.suivez": "Follow us",
  "footer.droits": "All rights reserved.",
  "footer.liens": "Useful links",
  "footer.metiers": "Business lines",
  "footer.contact": "Contact",
  "footer.newsletter": "Newsletter",
  "footer.newsletterTexte": "Get our news and opportunities.",
  "ia.titre": "AI Assistant",
  "ia.sousTitre": "Your guide across the site",
  "ia.placeholder": "Ask your question…",
  "ia.bienvenue": "Hello! I am the KasayiMultiBusiness assistant. How can I help you?",
  "ia.suggestion1": "What are your business lines?",
  "ia.suggestion2": "How do I request a quote?",
  "ia.suggestion3": "Where are you located?",
  "ia.envoyer": "Send",
  "ia.effacer": "New conversation",
  "ia.erreur": "An error occurred. Please try again.",
  "commun.chargement": "Loading…",
  "commun.enSavoirPlus": "Learn more",
};

const pt: Dico = {
  "nav.accueil": "Início",
  "nav.metiers": "Nossas atividades",
  "nav.realisations": "Realizações",
  "nav.equipe": "Equipa",
  "nav.flotte": "Frota",
  "nav.actualites": "Notícias",
  "nav.apropos": "Sobre nós",
  "nav.aide": "Ajuda",
  "nav.contact": "Contacto",
  "nav.toutesActivites": "Ver todas as atividades",
  "cta.connexion": "Entrar",
  "cta.monCompte": "Minha conta",
  "cta.espaceAgent": "Área do agente",
  "cta.devis": "Pedir orçamento",
  "cta.decouvrir": "Descobrir",
  "cta.contactez": "Fale connosco",
  "cta.envoyer": "Enviar",
  "langue.titre": "Idioma",
  "footer.suivez": "Siga-nos",
  "footer.droits": "Todos os direitos reservados.",
  "footer.liens": "Links úteis",
  "footer.metiers": "Atividades",
  "footer.contact": "Contacto",
  "footer.newsletter": "Newsletter",
  "footer.newsletterTexte": "Receba as nossas notícias e oportunidades.",
  "ia.titre": "Assistente IA",
  "ia.sousTitre": "O seu guia em todo o site",
  "ia.placeholder": "Faça a sua pergunta…",
  "ia.bienvenue": "Olá! Sou o assistente da KasayiMultiBusiness. Como posso ajudar?",
  "ia.suggestion1": "Quais são as vossas atividades?",
  "ia.suggestion2": "Como pedir um orçamento?",
  "ia.suggestion3": "Onde estão localizados?",
  "ia.envoyer": "Enviar",
  "ia.effacer": "Nova conversa",
  "ia.erreur": "Ocorreu um erro. Tente novamente.",
  "commun.chargement": "A carregar…",
  "commun.enSavoirPlus": "Saber mais",
};

const es: Dico = {
  "nav.accueil": "Inicio",
  "nav.metiers": "Nuestras actividades",
  "nav.realisations": "Realizaciones",
  "nav.equipe": "Equipo",
  "nav.flotte": "Flota",
  "nav.actualites": "Noticias",
  "nav.apropos": "Acerca de",
  "nav.aide": "Ayuda",
  "nav.contact": "Contacto",
  "nav.toutesActivites": "Ver todas nuestras actividades",
  "cta.connexion": "Iniciar sesión",
  "cta.monCompte": "Mi cuenta",
  "cta.espaceAgent": "Área de agentes",
  "cta.devis": "Solicitar presupuesto",
  "cta.decouvrir": "Descubrir",
  "cta.contactez": "Contáctenos",
  "cta.envoyer": "Enviar",
  "langue.titre": "Idioma",
  "footer.suivez": "Síguenos",
  "footer.droits": "Todos los derechos reservados.",
  "footer.liens": "Enlaces útiles",
  "footer.metiers": "Actividades",
  "footer.contact": "Contacto",
  "footer.newsletter": "Boletín",
  "footer.newsletterTexte": "Reciba nuestras noticias y oportunidades.",
  "ia.titre": "Asistente IA",
  "ia.sousTitre": "Su guía en todo el sitio",
  "ia.placeholder": "Haga su pregunta…",
  "ia.bienvenue": "¡Hola! Soy el asistente de KasayiMultiBusiness. ¿En qué puedo ayudarle?",
  "ia.suggestion1": "¿Cuáles son sus actividades?",
  "ia.suggestion2": "¿Cómo solicitar un presupuesto?",
  "ia.suggestion3": "¿Dónde están ubicados?",
  "ia.envoyer": "Enviar",
  "ia.effacer": "Nueva conversación",
  "ia.erreur": "Se produjo un error. Inténtelo de nuevo.",
  "commun.chargement": "Cargando…",
  "commun.enSavoirPlus": "Saber más",
};

const zh: Dico = {
  "nav.accueil": "首页",
  "nav.metiers": "业务领域",
  "nav.realisations": "项目成果",
  "nav.equipe": "团队",
  "nav.flotte": "车队",
  "nav.actualites": "新闻",
  "nav.apropos": "关于我们",
  "nav.aide": "帮助",
  "nav.contact": "联系",
  "nav.toutesActivites": "查看全部业务",
  "cta.connexion": "登录",
  "cta.monCompte": "我的账户",
  "cta.espaceAgent": "员工入口",
  "cta.devis": "获取报价",
  "cta.decouvrir": "了解",
  "cta.contactez": "联系我们",
  "cta.envoyer": "发送",
  "langue.titre": "语言",
  "footer.suivez": "关注我们",
  "footer.droits": "版权所有。",
  "footer.liens": "常用链接",
  "footer.metiers": "业务领域",
  "footer.contact": "联系方式",
  "footer.newsletter": "订阅通讯",
  "footer.newsletterTexte": "获取我们的最新资讯与商机。",
  "ia.titre": "AI 助手",
  "ia.sousTitre": "全站智能向导",
  "ia.placeholder": "请输入您的问题…",
  "ia.bienvenue": "您好！我是 KasayiMultiBusiness 的智能助手，请问需要什么帮助？",
  "ia.suggestion1": "你们有哪些业务？",
  "ia.suggestion2": "如何申请报价？",
  "ia.suggestion3": "你们位于哪里？",
  "ia.envoyer": "发送",
  "ia.effacer": "新对话",
  "ia.erreur": "发生错误，请重试。",
  "commun.chargement": "加载中…",
  "commun.enSavoirPlus": "了解更多",
};

const sw: Dico = {
  "nav.accueil": "Mwanzo",
  "nav.metiers": "Shughuli zetu",
  "nav.realisations": "Mafanikio",
  "nav.equipe": "Timu",
  "nav.flotte": "Magari",
  "nav.actualites": "Habari",
  "nav.apropos": "Kuhusu sisi",
  "nav.aide": "Msaada",
  "nav.contact": "Mawasiliano",
  "nav.toutesActivites": "Ona shughuli zote",
  "cta.connexion": "Ingia",
  "cta.monCompte": "Akaunti yangu",
  "cta.espaceAgent": "Eneo la wafanyakazi",
  "cta.devis": "Omba bei",
  "cta.decouvrir": "Gundua",
  "cta.contactez": "Wasiliana nasi",
  "cta.envoyer": "Tuma",
  "langue.titre": "Lugha",
  "footer.suivez": "Tufuate",
  "footer.droits": "Haki zote zimehifadhiwa.",
  "footer.liens": "Viungo muhimu",
  "footer.metiers": "Shughuli",
  "footer.contact": "Mawasiliano",
  "footer.newsletter": "Jarida",
  "footer.newsletterTexte": "Pokea habari na fursa zetu.",
  "ia.titre": "Msaidizi wa AI",
  "ia.sousTitre": "Mwongozo wako kwenye tovuti",
  "ia.placeholder": "Uliza swali lako…",
  "ia.bienvenue": "Habari! Mimi ni msaidizi wa KasayiMultiBusiness. Nikusaidie nini?",
  "ia.suggestion1": "Shughuli zenu ni zipi?",
  "ia.suggestion2": "Naombaje bei?",
  "ia.suggestion3": "Mko wapi?",
  "ia.envoyer": "Tuma",
  "ia.effacer": "Mazungumzo mapya",
  "ia.erreur": "Hitilafu imetokea. Jaribu tena.",
  "commun.chargement": "Inapakia…",
  "commun.enSavoirPlus": "Jifunze zaidi",
};

const ln: Dico = {
  "nav.accueil": "Ebandeli",
  "nav.metiers": "Misala na biso",
  "nav.realisations": "Misala esalemi",
  "nav.equipe": "Ekipi",
  "nav.flotte": "Mituka",
  "nav.actualites": "Sango",
  "nav.apropos": "Mpo na biso",
  "nav.aide": "Lisalisi",
  "nav.contact": "Kokutana",
  "nav.toutesActivites": "Tala misala nyonso",
  "cta.connexion": "Kokota",
  "cta.monCompte": "Kompte na ngai",
  "cta.espaceAgent": "Esika ya basali",
  "cta.devis": "Senga ntalo",
  "cta.decouvrir": "Yeba",
  "cta.contactez": "Benga biso",
  "cta.envoyer": "Tinda",
  "langue.titre": "Monoko",
  "footer.suivez": "Landa biso",
  "footer.droits": "Makoki nyonso ebatelami.",
  "footer.liens": "Ba lien ya ntina",
  "footer.metiers": "Misala",
  "footer.contact": "Kokutana",
  "footer.newsletter": "Nsango",
  "footer.newsletterTexte": "Zwa basango mpe mabaku na biso.",
  "ia.titre": "Mosungi IA",
  "ia.sousTitre": "Motambwisi na yo na site mobimba",
  "ia.placeholder": "Tuna motuna na yo…",
  "ia.bienvenue": "Mbote ! Nazali mosungi ya KasayiMultiBusiness. Nasalisa yo boni ?",
  "ia.suggestion1": "Misala na bino nini ?",
  "ia.suggestion2": "Ndenge nini kosenga ntalo ?",
  "ia.suggestion3": "Bozali wapi ?",
  "ia.envoyer": "Tinda",
  "ia.effacer": "Lisolo ya sika",
  "ia.erreur": "Libunga esalemi. Meka lisusu.",
  "commun.chargement": "Ezali kokota…",
  "commun.enSavoirPlus": "Yeba mingi",
};

export const DICTIONNAIRES: Record<Langue, Dico> = { fr, en, pt, es, zh, sw, ln };

export function traduire(langue: Langue, cle: CleTraduction): string {
  return DICTIONNAIRES[langue]?.[cle] ?? DICTIONNAIRES[LANGUE_DEFAUT][cle] ?? cle;
}

/** Consigne envoyée à l'IA pour qu'elle réponde dans la langue du visiteur. */
export const CONSIGNE_LANGUE: Record<Langue, string> = {
  fr: "Réponds en français.",
  en: "Answer in English.",
  pt: "Responda em português.",
  es: "Responde en español.",
  zh: "请用简体中文回答。",
  sw: "Jibu kwa Kiswahili.",
  ln: "Yanola na Lingála.",
};
