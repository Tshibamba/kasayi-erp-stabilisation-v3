"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Edit3, Loader2 } from "lucide-react";
import { Modal } from "@/components/agriculture/modal";
import { Button, Field, Input, Select, Textarea } from "@/components/agriculture/ui";
import type { FormField } from "./generic-form";

export function EditButton({ endpoint, title, fields, initialValues }: {
  endpoint: string;
  title: string;
  fields: FormField[];
  initialValues: Record<string, string | number | null | undefined>;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [values, setValues] = useState<Record<string, string>>(() => Object.fromEntries(
    fields.map((f) => [f.name, initialValues[f.name] == null ? "" : String(initialValues[f.name])])
  ));
  const set = (name: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setValues((v) => ({ ...v, [name]: e.target.value }));
  const submit = async () => {
    setLoading(true); setError(null);
    try {
      const payload: Record<string, unknown> = {};
      for (const f of fields) {
        const v = values[f.name] ?? "";
        payload[f.name] = f.type === "number" ? (v === "" ? 0 : Number(v)) : v;
      }
      const res = await fetch(endpoint, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || "Échec de la modification.");
      setOpen(false); router.refresh();
    } catch (e) { setError((e as Error).message); }
    finally { setLoading(false); }
  };
  return <>
    <button type="button" title="Modifier" onClick={() => setOpen(true)} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-ciel/10 hover:text-ciel">
      <Edit3 size={15} />
    </button>
    <Modal open={open} onClose={() => setOpen(false)} title={title} size="lg">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {fields.map((f) => <div key={f.name} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
          <Field label={f.label} required={f.required}>
            {f.type === "select" ? <Select value={values[f.name] ?? ""} onChange={set(f.name)}><option value="">— Sélectionner —</option>{f.options?.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</Select> : f.type === "textarea" ? <Textarea rows={4} value={values[f.name] ?? ""} onChange={set(f.name)} placeholder={f.placeholder} /> : <Input type={f.type === "number" ? "number" : f.type === "date" ? "date" : "text"} step={f.type === "number" ? "0.01" : undefined} value={values[f.name] ?? ""} onChange={set(f.name)} placeholder={f.placeholder} />}
          </Field>
        </div>)}
      </div>
      {error && <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-danger">{error}</p>}
      <div className="mt-5 flex justify-end gap-3"><Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button><Button onClick={submit} disabled={loading}>{loading ? <Loader2 size={16} className="animate-spin" /> : null} Enregistrer</Button></div>
    </Modal>
  </>;
}
