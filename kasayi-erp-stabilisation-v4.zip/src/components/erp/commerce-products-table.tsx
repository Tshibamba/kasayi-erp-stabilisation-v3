"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, SlidersHorizontal } from "lucide-react";
import { Card } from "@/components/agriculture/ui";
import { EditButton } from "@/components/erp/edit-button";
import { DeleteButton } from "@/components/erp/row-actions";
import { formatMontant, formatNombre, toNum } from "@/lib/format";

type Product = { id:number; nom:string; categorie:string|null; unite:string; prixAchat:string; prixVente:string; stockMin:string; stock:string };

export function CommerceProductsTable({ items }: { items: Product[] }) {
  const [q,setQ]=useState(""); const [cat,setCat]=useState("ALL"); const [stock,setStock]=useState("ALL");
  const cats=useMemo(()=>Array.from(new Set(items.map(x=>x.categorie).filter(Boolean))) as string[],[items]);
  const filtered=useMemo(()=>items.filter(p=>{
    const text=`${p.nom} ${p.categorie??""}`.toLowerCase().includes(q.toLowerCase());
    const category=cat==="ALL"||p.categorie===cat;
    const st=stock==="ALL"||(stock==="LOW"?toNum(p.stock)<=toNum(p.stockMin):stock==="OUT"?toNum(p.stock)<=0:toNum(p.stock)>toNum(p.stockMin));
    return text&&category&&st;
  }),[items,q,cat,stock]);
  return <Card className="overflow-hidden">
    <div className="border-b border-slate-100 p-4"><div className="flex flex-wrap items-center gap-2"><div className="relative min-w-[220px] flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Rechercher un article..." className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm outline-none focus:border-ciel"/></div><select value={cat} onChange={e=>setCat(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2.5 text-sm"><option value="ALL">Toutes les catégories</option>{cats.map(c=><option key={c}>{c}</option>)}</select><select value={stock} onChange={e=>setStock(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2.5 text-sm"><option value="ALL">Tous les stocks</option><option value="LOW">Stock faible</option><option value="OUT">Rupture</option><option value="OK">Stock normal</option></select><span className="inline-flex items-center gap-1 text-xs text-slate-400"><SlidersHorizontal size={14}/>{filtered.length}/{items.length}</span></div></div>
    <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm"><thead><tr className="bg-slate-50/60 text-xs uppercase tracking-wide text-slate-400"><th className="px-5 py-2.5">Article</th><th className="px-5 py-2.5">Catégorie</th><th className="px-5 py-2.5 text-right">Stock</th><th className="px-5 py-2.5 text-right">Prix achat</th><th className="px-5 py-2.5 text-right">Prix vente</th><th className="px-5 py-2.5 text-right">Marge</th><th className="px-5 py-2.5 text-right">Actions</th></tr></thead><tbody className="divide-y divide-slate-50">{filtered.map(p=>{const marge=toNum(p.prixVente)-toNum(p.prixAchat); const faible=toNum(p.stock)<=toNum(p.stockMin); return <tr key={p.id} className="hover:bg-slate-50/60"><td className="px-5 py-3.5 font-semibold">{p.nom}</td><td className="px-5 py-3.5 text-slate-500">{p.categorie??"—"}</td><td className={`px-5 py-3.5 text-right font-semibold ${faible?"text-danger":""}`}>{formatNombre(toNum(p.stock))} {p.unite}</td><td className="px-5 py-3.5 text-right">{formatMontant(toNum(p.prixAchat),"CDF")}</td><td className="px-5 py-3.5 text-right">{formatMontant(toNum(p.prixVente),"CDF")}</td><td className="px-5 py-3.5 text-right font-semibold text-emerald-600">+{formatMontant(marge,"CDF")}</td><td className="px-5 py-3.5"><div className="flex justify-end gap-1"><EditButton endpoint={`/api/commerce/products/${p.id}`} title="Modifier l'article" initialValues={p} fields={[{name:"nom",label:"Nom",required:true},{name:"categorie",label:"Catégorie"},{name:"unite",label:"Unité"},{name:"prixAchat",label:"Prix d'achat",type:"number"},{name:"prixVente",label:"Prix de vente",type:"number"},{name:"stock",label:"Stock",type:"number"},{name:"stockMin",label:"Stock minimum",type:"number"}]}/><DeleteButton endpoint={`/api/commerce/products/${p.id}`}/></div></td></tr>})}</tbody></table></div>
    {filtered.length===0&&<p className="p-8 text-center text-sm text-slate-400">Aucun article ne correspond aux critères.</p>}
  </Card>;
}
