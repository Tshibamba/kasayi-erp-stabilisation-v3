"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Card } from "@/components/agriculture/ui";
import { EditButton } from "@/components/erp/edit-button";
import { DeleteButton } from "@/components/erp/row-actions";
import { formatDate } from "@/lib/format";

type Fournisseur = {
  id: number; nom: string; telephone: string | null; email: string | null;
  adresse: string | null; contact: string | null; typeSemence: string | null;
  conditionsPaiement: string | null; createdAt: Date;
};

export function FournisseursTable({ items }: { items: Fournisseur[] }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return items;
    return items.filter((f) => `${f.nom} ${f.telephone ?? ""} ${f.email ?? ""} ${f.adresse ?? ""} ${f.contact ?? ""} ${f.typeSemence ?? ""}`.toLowerCase().includes(needle));
  }, [items, q]);

  return <Card className="overflow-hidden">
    <div className="border-b border-slate-100 p-4">
      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16}/>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher par nom, téléphone, email, contact..." className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm outline-none focus:border-ciel"/>
      </div>
      <p className="mt-2 text-xs text-slate-400">{filtered.length} / {items.length} fournisseur(s)</p>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full min-w-[900px] text-left text-sm">
        <thead><tr className="bg-slate-50/60 text-xs uppercase tracking-wide text-slate-400">
          <th className="px-5 py-2.5">Fournisseur</th><th className="px-5 py-2.5">Contact</th><th className="px-5 py-2.5">Téléphone</th><th className="px-5 py-2.5">Email</th><th className="px-5 py-2.5">Depuis</th><th className="px-5 py-2.5 text-right">Actions</th>
        </tr></thead>
        <tbody className="divide-y divide-slate-50">
          {filtered.map((f) => <tr key={f.id} className="hover:bg-slate-50/60">
            <td className="px-5 py-3.5 font-semibold text-slate-900">{f.nom}</td>
            <td className="px-5 py-3.5 text-slate-600">{f.contact ?? "—"}</td>
            <td className="px-5 py-3.5 text-slate-600">{f.telephone ?? "—"}</td>
            <td className="px-5 py-3.5 text-slate-600">{f.email ?? "—"}</td>
            <td className="px-5 py-3.5 text-slate-500">{formatDate(f.createdAt)}</td>
            <td className="px-5 py-3.5"><div className="flex justify-end gap-1">
              <EditButton endpoint={`/api/agriculture/fournisseurs/${f.id}`} title="Modifier le fournisseur" initialValues={f} fields={[
                {name:"nom",label:"Nom",required:true},{name:"contact",label:"Contact"},{name:"telephone",label:"Téléphone"},{name:"email",label:"Email"},{name:"adresse",label:"Adresse"},{name:"typeSemence",label:"Type de semence"},{name:"conditionsPaiement",label:"Conditions de paiement"}
              ]}/>
              <DeleteButton endpoint={`/api/agriculture/fournisseurs/${f.id}`}/>
            </div></td>
          </tr>)}
        </tbody>
      </table>
    </div>
    {filtered.length === 0 && <p className="p-8 text-center text-sm text-slate-400">Aucun fournisseur ne correspond à la recherche.</p>}
  </Card>;
}
