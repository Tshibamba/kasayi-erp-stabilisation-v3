"use client";

import { useMemo, useState } from "react";
import { Search, RotateCcw } from "lucide-react";
import { Card, StatutStockBadge, CategorieChip } from "@/components/agriculture/ui";
import { EditButton } from "@/components/erp/edit-button";
import { DeleteButton } from "@/components/erp/row-actions";
import { CATEGORIES } from "@/lib/ui/agriculture";
import { formatMontant, formatNombre } from "@/lib/format";

type Item = { produitId:number; nom:string; categorie:string; unite:string; quantite:any; cmup:any; seuilAlerte:any; seuilCritique:any; statut:string };

export function ProduitsTable({ items }: { items: Item[] }) {
  const [q,setQ]=useState(""); const [cat,setCat]=useState("TOUS"); const [statut,setStatut]=useState("TOUS");
  const cats=useMemo(()=>Array.from(new Set(items.map(i=>i.categorie))),[items]);
  const filtered=useMemo(()=>items.filter(i=>
    `${i.nom} ${i.categorie}`.toLowerCase().includes(q.toLowerCase()) &&
    (cat==="TOUS" || i.categorie===cat) &&
    (statut==="TOUS" || i.statut===statut)
  ),[items,q,cat,statut]);
  const reset=()=>{setQ("");setCat("TOUS");setStatut("TOUS")};
  return <Card className="overflow-hidden">
    <div className="border-b border-slate-100 p-4">
      <div className="flex flex-wrap gap-2">
        <div className="relative min-w-[220px] flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Rechercher un produit..." className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm outline-none focus:border-ciel"/></div>
        <select value={cat} onChange={e=>setCat(e.target.value)} className="rounded-xl border border-slate-200 px-3 text-sm"><option value="TOUS">Toutes catégories</option>{cats.map(c=><option key={c} value={c}>{CATEGORIES.find(x=>x.value===c)?.label??c}</option>)}</select>
        <select value={statut} onChange={e=>setStatut(e.target.value)} className="rounded-xl border border-slate-200 px-3 text-sm"><option value="TOUS">Tous statuts</option>{["OK","FAIBLE","CRITIQUE","RUPTURE","SURSTOCK"].map(x=><option key={x}>{x}</option>)}</select>
        <button onClick={reset} className="inline-flex items-center gap-1 rounded-xl border border-slate-200 px-3 text-sm text-slate-600 hover:bg-slate-50"><RotateCcw size={14}/> Réinitialiser</button>
      </div>
      <p className="mt-2 text-xs text-slate-400">{filtered.length} / {items.length} produit(s)</p>
    </div>
    <div className="overflow-x-auto"><table className="w-full min-w-[1000px] text-left text-sm"><thead><tr className="bg-slate-50/60 text-xs uppercase tracking-wide text-slate-400"><th className="px-5 py-2.5">Produit</th><th className="px-5 py-2.5">Catégorie</th><th className="px-5 py-2.5 text-right">Quantité</th><th className="px-5 py-2.5 text-right">CMUP</th><th className="px-5 py-2.5">Statut</th><th className="px-5 py-2.5 text-right">Actions</th></tr></thead>
    <tbody className="divide-y divide-slate-50">{filtered.map(i=><tr key={i.produitId} className="hover:bg-slate-50/60">
      <td className="px-5 py-3.5 font-semibold">{i.nom}</td><td className="px-5 py-3.5"><CategorieChip categorie={i.categorie}/></td><td className="px-5 py-3.5 text-right">{formatNombre(i.quantite)} {i.unite}</td><td className="px-5 py-3.5 text-right">{formatMontant(i.cmup,"CDF")}</td><td className="px-5 py-3.5"><StatutStockBadge statut={i.statut}/></td>
      <td className="px-5 py-3.5"><div className="flex justify-end gap-1"><EditButton endpoint={`/api/agriculture/produits/${i.produitId}`} title="Modifier le produit" initialValues={{nom:i.nom,categorie:i.categorie,unite:i.unite}} fields={[{name:"nom",label:"Nom",required:true},{name:"categorie",label:"Catégorie",type:"select",options:CATEGORIES.map(c=>({value:c.value,label:c.label}))},{name:"unite",label:"Unité"}]}/><DeleteButton endpoint={`/api/agriculture/produits/${i.produitId}`}/></div></td>
    </tr>)}</tbody></table></div>
    {filtered.length===0&&<p className="p-8 text-center text-sm text-slate-400">Aucun produit ne correspond aux critères.</p>}
  </Card>;
}
