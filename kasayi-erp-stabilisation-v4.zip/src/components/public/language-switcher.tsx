"use client";

import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown, Globe } from "lucide-react";
import { LANGUES, type Langue } from "@/lib/i18n/dictionaries";
import { useI18n } from "@/lib/i18n/context";

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { langue, setLangue, t } = useI18n();
  const [ouvert, setOuvert] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOuvert(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const active = LANGUES.find((l) => l.code === langue) ?? LANGUES[0];

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOuvert((o) => !o)}
        aria-label={t("langue.titre")}
        aria-expanded={ouvert}
        className="group flex items-center gap-2 rounded-full border border-slate-200 bg-white/90 px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:border-marine/30 hover:shadow-md"
      >
        <Globe size={16} />
        <span className="grid h-6 w-6 place-items-center rounded-full bg-slate-50 text-base shadow-inner">{active.drapeau}</span>
        <span className="uppercase tracking-wide">{active.code}</span>
        <ChevronDown size={14} className={`transition ${ouvert ? "rotate-180" : ""}`} />
      </button>

      {ouvert && (
        <div className="absolute right-0 top-full z-50 mt-2 w-56 overflow-hidden rounded-2xl border border-slate-200 bg-white/95 p-1.5 shadow-2xl backdrop-blur">
          <p className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            {t("langue.titre")}
          </p>
          {LANGUES.map((l) => (
            <button
              key={l.code}
              type="button"
              onClick={() => {
                setLangue(l.code as Langue);
                setOuvert(false);
              }}
              className={`flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-sm transition ${
                l.code === langue ? "bg-marine/5 font-bold text-marine" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <span className="flex items-center gap-2">
                <span className="text-base">{l.drapeau}</span>
                {l.label}
              </span>
              {l.code === langue && <Check size={15} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
