"use client";

import { useEffect } from "react";
import { useI18n } from "@/lib/i18n/context";

const MAP: Record<string, Record<string,string>> = {
  "Dernières news": {en:"Latest news",es:"Últimas noticias",pt:"Últimas notícias",zh:"最新新闻"},
  "Toutes les actualités": {en:"All news",es:"Todas las noticias",pt:"Todas as notícias",zh:"所有新闻"},
  "Aucune actualité pour le moment.": {en:"No news at the moment.",es:"No hay noticias por el momento.",pt:"Nenhuma notícia no momento.",zh:"目前暂无新闻。"},
  "En images": {en:"In pictures",es:"En imágenes",pt:"Em imagens",zh:"图片"},
  "Notre univers en photos": {en:"Our world in pictures",es:"Nuestro mundo en fotos",pt:"Nosso universo em fotos",zh:"我们的照片"},
  "Faites glisser pour découvrir nos activités en action.": {en:"Explore our activities in action.",es:"Descubra nuestras actividades en acción.",pt:"Descubra nossas atividades em ação.",zh:"探索我们的活动现场。"},
  "Pourquoi nous choisir ?": {en:"Why choose us?",es:"¿Por qué elegirnos?",pt:"Por que nos escolher?",zh:"为什么选择我们？"},
  "Une entreprise locale, professionnelle et fiable.": {en:"A local, professional and reliable company.",es:"Una empresa local, profesional y fiable.",pt:"Uma empresa local, profissional e fiável.",zh:"一家本地、专业且可靠的企业。"},
  "Témoignages": {en:"Testimonials",es:"Testimonios",pt:"Testemunhos",zh:"客户评价"},
  "Ils nous font confiance": {en:"They trust us",es:"Confían en nosotros",pt:"Eles confiam em nós",zh:"他们信任我们"},
  "Ils nous accompagnent": {en:"Our partners",es:"Nuestros socios",pt:"Nossos parceiros",zh:"我们的合作伙伴"},
  "Nos métiers": {en:"Our business lines",es:"Nuestras actividades",pt:"Nossas atividades",zh:"我们的业务"},
  "Navigation": {en:"Navigation",es:"Navegación",pt:"Navegação",zh:"导航"},
  "Contact": {en:"Contact",es:"Contacto",pt:"Contacto",zh:"联系"},
  "Accueil": {en:"Home",es:"Inicio",pt:"Início",zh:"首页"},
  "Actualités": {en:"News",es:"Noticias",pt:"Notícias",zh:"新闻"},
  "Notre équipe": {en:"Our team",es:"Nuestro equipo",pt:"Nossa equipa",zh:"我们的团队"},
  "Notre flotte": {en:"Our fleet",es:"Nuestra flota",pt:"Nossa frota",zh:"我们的车队"},
  "À propos": {en:"About us",es:"Acerca de nosotros",pt:"Sobre nós",zh:"关于我们"},
  "Aide": {en:"Help",es:"Ayuda",pt:"Ajuda",zh:"帮助"},
  "Entreprise multi-activités au Kasaï Central : agriculture, commerce, transport, sous-traitance et service traiteur.": {en:"A multi-activity company in Central Kasaï: agriculture, commerce, transport, subcontracting and catering.",es:"Empresa multiservicios en Kasaï Central: agricultura, comercio, transporte, subcontratación y catering.",pt:"Empresa multiactividades no Kasaï Central: agricultura, comércio, transporte, subcontratação e serviço de catering.",zh:"位于开赛省中部的多元化企业：农业、商业、运输、分包和餐饮服务。"},
};

export function PublicTextTranslator() {
  const { langue } = useI18n();
  useEffect(() => {
    const root = document.querySelector("main");
    if (!root) return;
    const apply = () => {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      const nodes: Text[] = [];
      let n: Node | null;
      while ((n = walker.nextNode())) nodes.push(n as Text);
      for (const node of nodes) {
        const el = node.parentElement;
        if (!el || ["SCRIPT","STYLE","INPUT","TEXTAREA"].includes(el.tagName)) continue;
        const stored = el.getAttribute("data-i18n-original");
        const original = stored ?? node.nodeValue?.trim();
        if (!original || !MAP[original]) continue;
        if (!stored) el.setAttribute("data-i18n-original", original);
        const translated = langue === "fr" ? original : MAP[original][langue] ?? original;
        node.nodeValue = node.nodeValue!.replace(node.nodeValue!.trim(), translated);
      }
    };
    apply();
    const observer = new MutationObserver(() => apply());
    observer.observe(root, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [langue]);
  return null;
}
