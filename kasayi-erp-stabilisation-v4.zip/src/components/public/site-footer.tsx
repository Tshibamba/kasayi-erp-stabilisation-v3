"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Leaf, MapPin, Phone, Mail, Send } from "lucide-react";
import { useI18n } from "@/lib/i18n/context";
import { NewsletterForm } from "@/components/public/newsletter-form";

type Service = { slug:string; nom:string; emoji:string|null };

export function SiteFooter() {
  const { t } = useI18n();
  const [items,setItems]=useState<Service[]>([]);
  useEffect(()=>{ fetch("/api/services").then(r=>r.json()).then(d=>setItems(d.items??[])).catch(()=>{}); },[]);
  const annee = new Date().getFullYear();

  return <footer className="bg-[#142a3f] text-slate-300">
    <div className="border-b border-white/10"><div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-8 text-center lg:flex-row lg:px-8 lg:text-left">
      <div className="max-w-md"><h4 className="flex items-center gap-2 font-display text-lg font-bold text-white"><Send size={18} className="text-or"/> {t("footer.newsletter")}</h4><p className="mt-1 text-sm text-slate-400">{t("footer.newsletterTexte")}</p></div>
      <div className="w-full max-w-md"><NewsletterForm variant="dark"/></div>
    </div></div>
    <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
      <div><div className="flex items-center gap-2.5"><span className="grid h-9 w-9 place-items-center rounded-lg bg-or text-white"><Leaf size={20}/></span><span className="font-display text-lg font-bold text-white">KasayiMultiBusiness</span></div><p className="mt-4 text-sm leading-relaxed text-slate-400">Entreprise multi-activités au Kasaï Central : agriculture, commerce, transport, sous-traitance et service traiteur.</p></div>
      <div><h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">{t("footer.metiers")}</h4><ul className="mt-4 space-y-2 text-sm">{items.map(a=><li key={a.slug}><Link href={`/activites#${a.slug}`} className="text-slate-400 transition hover:text-or">{a.emoji} {a.nom}</Link></li>)}</ul></div>
      <div><h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">{t("footer.liens")}</h4><ul className="mt-4 space-y-2 text-sm">
        <li><Link href="/" className="text-slate-400 hover:text-or">{t("nav.accueil")}</Link></li><li><Link href="/actualites" className="text-slate-400 hover:text-or">{t("nav.actualites")}</Link></li><li><Link href="/equipe" className="text-slate-400 hover:text-or">{t("nav.equipe")}</Link></li><li><Link href="/flotte" className="text-slate-400 hover:text-or">{t("nav.flotte")}</Link></li><li><Link href="/a-propos" className="text-slate-400 hover:text-or">{t("nav.apropos")}</Link></li><li><Link href="/aide" className="text-slate-400 hover:text-or">{t("nav.aide")}</Link></li><li><Link href="/contact" className="text-slate-400 hover:text-or">{t("nav.contact")}</Link></li>
      </ul></div>
      <div><h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">{t("footer.contact")}</h4><ul className="mt-4 space-y-3 text-sm text-slate-400"><li className="flex items-start gap-2"><MapPin size={16} className="mt-0.5 shrink-0 text-or"/> Kasayi, Kananga — RD Congo</li><li className="flex items-center gap-2"><Phone size={16} className="shrink-0 text-or"/> +243 000 000 000</li><li className="flex items-center gap-2"><Mail size={16} className="shrink-0 text-or"/> contact@kasayimultibusiness.cd</li></ul></div>
    </div>
    <div className="border-t border-white/10"><div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-slate-500 sm:flex-row lg:px-8"><p>© {annee} KasayiMultiBusiness. {t("footer.droits")}</p><p>RD Congo · Conformité comptable SYSCOHADA</p></div></div>
  </footer>;
}
