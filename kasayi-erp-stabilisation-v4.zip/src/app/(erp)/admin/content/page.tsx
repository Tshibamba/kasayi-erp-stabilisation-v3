import { redirect } from "next/navigation";
export default function ContentAliasPage() { redirect("/admin/contenu"); }
