
import { EmptyState } from "@/components/agriculture/ui";
import { FournisseurDialog } from "@/components/agriculture/fournisseur-dialog";
import { db } from "@/db";
import { fournisseur } from "@/db/schema";
import { asc } from "drizzle-orm";
import { FournisseursTable } from "@/components/agriculture/fournisseurs-table";

export const dynamic = "force-dynamic";

export default async function FournisseursPage() {
  let items: typeof fournisseur.$inferSelect[] = [];
  try {
    items = await db.select().from(fournisseur).orderBy(asc(fournisseur.nom));
  } catch {
    /* ignore */
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-ciel">Achats</p>
          <h1 className="font-display text-2xl font-bold text-slate-900 lg:text-3xl">Fournisseurs d'intrants</h1>
          <p className="mt-1 text-sm text-slate-500">Recherche, modification et suppression des fournisseurs.</p>
        </div>
        <FournisseurDialog />
      </div>
      {items.length === 0 ? (
        <EmptyState emoji="🚚" title="Aucun fournisseur" description="Ajoutez vos fournisseurs pour les associer aux bons de commande d'intrants." action={<FournisseurDialog />} />
      ) : <FournisseursTable items={items} />}
    </div>
  );
}
