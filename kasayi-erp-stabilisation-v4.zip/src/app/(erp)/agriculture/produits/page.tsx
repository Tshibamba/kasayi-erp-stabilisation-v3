import { Card, EmptyState } from "@/components/agriculture/ui";
import { ProduitDialog } from "@/components/agriculture/produit-dialog";
import { SeedButton } from "@/components/agriculture/seed-button";
import { ProduitsTable } from "@/components/agriculture/produits-table";
import { getStocksListe } from "@/lib/agriculture/stock-service";

export const dynamic = "force-dynamic";

export default async function ProduitsPage() {
  let data: Awaited<ReturnType<typeof getStocksListe>> = { items: [], stats: { totalProduits: 0, valeurTotale: 0, enAlerte: 0, critiques: 0, ruptures: 0, ok: 0 } };
  try { data = await getStocksListe(); } catch {}
  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><p className="text-sm font-medium text-ciel">Catalogue</p><h1 className="font-display text-2xl font-bold text-slate-900 lg:text-3xl">Produits intrants</h1><p className="mt-1 text-sm text-slate-500">Recherche multicritère, modification et suppression.</p></div>
        <ProduitDialog />
      </div>
      {data.items.length === 0 ? <Card className="p-8"><EmptyState emoji="🌱" title="Aucun produit" description="Créez votre premier intrant ou chargez les données de démonstration." action={<SeedButton/>}/></Card> : <ProduitsTable items={data.items as any} />}
    </div>
  );
}
