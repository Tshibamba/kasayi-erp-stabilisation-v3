import { redirect } from "next/navigation";
export default function StockAliasPage() { redirect("/agriculture/stocks"); }
