import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { commerceProducts } from "@/db/schema";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function PATCH(req: NextRequest,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;const b=await req.json();const v:Record<string,unknown>={};for(const c of ["nom","categorie","unite"])if(b[c]!==undefined)v[c]=b[c]||null;for(const c of ["prixAchat","prixVente","stockMin","stock"])if(b[c]!==undefined)v[c]=String(b[c]??0);if(!Object.keys(v).length)return NextResponse.json({error:"Rien à mettre à jour."},{status:400});const [item]=await db.update(commerceProducts).set(v).where(eq(commerceProducts.id,Number(id))).returning();if(!item)return NextResponse.json({error:"Article introuvable."},{status:404});return NextResponse.json({item});}catch(e){return NextResponse.json({error:(e as Error).message},{status:500})}}
export async function DELETE(_req:NextRequest,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;await db.delete(commerceProducts).where(eq(commerceProducts.id,Number(id)));return NextResponse.json({ok:true})}catch(e){return NextResponse.json({error:(e as Error).message},{status:500})}}
