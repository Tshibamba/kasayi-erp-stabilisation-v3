import { NextRequest, NextResponse } from "next/server";
import { getCurrentStaff, getCurrentClient } from "@/lib/auth";
import { chat } from "@/lib/ai/service";
import { chatPublic } from "@/lib/ai/public-service";
import type { ChatMessage } from "@/lib/ai/types";
import { COOKIE_LANGUE, LANGUE_DEFAUT, LANGUES, type Langue } from "@/lib/i18n/dictionaries";

export const dynamic = "force-dynamic";

const CODES = LANGUES.map((l) => l.code) as readonly string[];

function resoudreLangue(req: NextRequest, body: { langue?: string }): Langue {
  const candidate = body.langue || req.cookies.get(COOKIE_LANGUE)?.value || "";
  return CODES.includes(candidate) ? (candidate as Langue) : LANGUE_DEFAUT;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages: ChatMessage[] = body.messages || [];
    if (messages.length === 0) {
      return NextResponse.json({ error: "Aucun message." }, { status: 400 });
    }

    const langue = resoudreLangue(req, body);
    const staff = await getCurrentStaff();
    const client = await getCurrentClient();
    const user = staff || client;

    // ── Visiteur non connecté : assistant PUBLIC ───────────────
    // Guide le visiteur sur tout le site, connecté à la base (services,
    // FAQ, actualités, coordonnées) mais sans aucune donnée financière.
    if (!user) {
      const res = await chatPublic(messages, langue);
      return NextResponse.json({ content: res.content, provider: res.provider, mode: "public" });
    }

    // ── Agent / client connecté : assistant ERP complet ────────
    const result = await chat(
      { messages, conversationId: body.conversationId },
      { id: user.id, name: staff?.name || client?.nom || "Utilisateur", role: staff?.roleId ?? undefined },
    );

    return NextResponse.json({ ...result, mode: staff ? "erp" : "client" });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message || "Erreur assistant IA." }, { status: 500 });
  }
}
