import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { fournisseur } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const [item] = await db.update(fournisseur).set({
      nom: body.nom ?? undefined,
      telephone: body.telephone ?? null,
      email: body.email ?? null,
      adresse: body.adresse ?? null,
      contact: body.contact ?? null,
      typeSemence: body.typeSemence ?? null,
      conditionsPaiement: body.conditionsPaiement ?? null,
    }).where(eq(fournisseur.id, Number(id))).returning();
    if (!item) return NextResponse.json({ error: "Fournisseur introuvable." }, { status: 404 });
    return NextResponse.json({ fournisseur: item });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(fournisseur).where(eq(fournisseur.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
