import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { depense } from "@/db/schema";
import { eq } from "drizzle-orm";
export const dynamic="force-dynamic";
export async function PATCH(req:NextRequest,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;const b=await req.json();const [item]=await db.update(depense).set({nature:b.nature??undefined,montant:String(b.montant??0),date:b.date??null,activite:b.activite??"general",categorie:b.categorie??null,responsable:b.responsable??null,modePaiement:b.modePaiement??null,justificatif:b.justificatif??null,notes:b.notes??null}).where(eq(depense.id,Number(id))).returning();if(!item)return NextResponse.json({error:"Dépense introuvable."},{status:404});return NextResponse.json({item})}catch(e){return NextResponse.json({error:(e as Error).message},{status:500})}}
export async function DELETE(_req:NextRequest,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;await db.delete(depense).where(eq(depense.id,Number(id)));return NextResponse.json({ok:true})}catch(e){return NextResponse.json({error:(e as Error).message},{status:500})}}
