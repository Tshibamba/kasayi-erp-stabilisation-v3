import type { NextConfig } from "next";

/**
 * `output: "standalone"` est nécessaire pour Docker / VPS (image légère),
 * mais inutile (et parfois gênant) pour un `next start` classique ou
 * un déploiement Vercel. On l'active donc via une variable d'environnement.
 *   BUILD_STANDALONE=1 npm run build   → build Docker/VPS
 */
const nextConfig: NextConfig = {
  // pdfkit charge ses métriques de polices (.afm) via fs au runtime
  serverExternalPackages: ["pdfkit"],
  ...(process.env.BUILD_STANDALONE === "1" ? { output: "standalone" as const } : {}),
  // Autorise le serveur HMR depuis une adresse réseau uniquement si elle est fournie.
  ...(process.env.ALLOWED_DEV_ORIGINS
    ? { allowedDevOrigins: process.env.ALLOWED_DEV_ORIGINS.split(",").map((v) => v.trim()).filter(Boolean) }
    : {}),
  images: {
    // Images locales dans /public/images — aucune dépendance externe.
    // Ajoutez ici un domaine si vous servez des médias distants.
    remotePatterns: [],
  },
};

export default nextConfig;
